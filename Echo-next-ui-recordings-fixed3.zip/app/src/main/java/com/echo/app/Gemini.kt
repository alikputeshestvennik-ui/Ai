package com.echo.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Gemini {

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    suspend fun transcribe(chunks: List<ByteArray>): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank() || chunks.isEmpty()) return@withContext ""

        val output = StringBuilder()
        val opened = CountDownLatch(1)
        val setupDone = CountDownLatch(1)
        val finished = CountDownLatch(1)

        val socket = client.newWebSocket(
            Request.Builder().url("$WS?key=$key").build(),
            object : WebSocketListener() {

                override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                    opened.countDown()

                    val setup = JSONObject()
                        .put(
                            "setup",
                            JSONObject()
                                .put("model", "models/gemini-3.5-transcribe-live")
                                .put(
                                    "generationConfig",
                                    JSONObject().put(
                                        "responseModalities",
                                        JSONArray().put("TEXT")
                                    )
                                )
                                .put(
                                    "inputAudioTranscription",
                                    JSONObject()
                                        .put("languageCodes", JSONArray().put("ru-RU"))
                                        .put("mode", "SMART")
                                )
                        )

                    webSocket.send(setup.toString())
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val json = JSONObject(text)

                        if (json.has("setupComplete")) {
                            setupDone.countDown()
                            return
                        }

                        val server = json.optJSONObject("serverContent") ?: return

                        server.optJSONObject("interimInputTranscription")
                            ?.optString("text")
                            ?.takeIf { it.isNotBlank() }
                            ?.let { interim ->
                                synchronized(output) {
                                    // Interim text is not persisted; it only confirms the API is receiving audio.
                                }
                            }

                        server.optJSONObject("inputTranscription")
                            ?.optString("text")
                            ?.takeIf { it.isNotBlank() }
                            ?.let { finalText ->
                                synchronized(output) {
                                    output.append(finalText).append(' ')
                                }
                            }

                        if (server.optBoolean("turnComplete", false)) {
                            finished.countDown()
                        }
                    } catch (_: Exception) {
                        // Ignore malformed protocol messages; timeout below closes the turn safely.
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                    Log.e("EchoGemini", "Live transcription WebSocket failed", t)
                    opened.countDown()
                    setupDone.countDown()
                    finished.countDown()
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    finished.countDown()
                }
            }
        )

        if (!opened.await(5, TimeUnit.SECONDS)) {
            socket.cancel()
            return@withContext ""
        }

        if (!setupDone.await(5, TimeUnit.SECONDS)) {
            socket.cancel()
            return@withContext ""
        }

        for (chunk in chunks) {
            val message = JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put(
                        "audio",
                        JSONObject()
                            .put(
                                "mimeType",
                                "audio/pcm;rate=16000"
                            )
                            .put(
                                "data",
                                Base64.encodeToString(chunk, Base64.NO_WRAP)
                            )
                    )
                )

            socket.send(message.toString())

            // Keep the stream paced close to real time instead of flooding the WebSocket.
            Thread.sleep(20)
        }

        socket.send(
            JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put("audioStreamEnd", true)
                )
                .toString()
        )

        finished.await(8, TimeUnit.SECONDS)
        socket.close(1000, "turn complete")

        synchronized(output) {
            output.toString().trim()
        }
    }

    suspend fun extract(prompt: String): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank()) return@withContext ""

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json")
            )

        val request = Request.Builder()
            .url(
                "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "gemini-3.5-flash-lite:generateContent?key=$key"
            )
            .post(
                body.toString()
                    .toRequestBody("application/json".toMediaType())
            )
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e("EchoGemini", "HTTP ${response.code}: ${response.body?.string()}")
                return@withContext ""
            }

            val responseBody = response.body?.string() ?: return@withContext ""
            val json = JSONObject(responseBody)

            json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}
