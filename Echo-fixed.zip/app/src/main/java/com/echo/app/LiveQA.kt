package com.echo.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// A second, independent Live session used for conversational Q&A about the
// user's own history (long-press + swipe-up on the FAB). Deliberately kept
// separate from Gemini (background transcription) -- the two run different
// models and can be active at the same time; sharing one socket/connected
// state between them would corrupt both.
object LiveQA {

    private const val TAG = "EchoLiveQA"
    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var connected = false
    @Volatile private var setupReady = false
    private var setupLatch: CountDownLatch? = null
    private val sendLock = Any()

    fun isConnected(): Boolean = connected && setupReady

    // systemContext carries the 7-day transcripts + long-term memory + full
    // day-summary history, so the model can answer questions grounded only
    // in what the user has actually said/recorded.
    suspend fun start(
        systemContext: String,
        onAnswerChunk: (String) -> Unit,
        onTurnComplete: () -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank()) {
            Log.e(TAG, "GEMINI_API_KEY is empty")
            return@withContext false
        }

        val latch = CountDownLatch(1)
        setupLatch = latch

        fun handleServerMessage(text: String) {
            try {
                val json = JSONObject(text)

                if (json.has("setupComplete")) {
                    setupReady = true
                    setupLatch?.countDown()
                    Log.d(TAG, "LiveQA setup complete")
                }

                val server = json.optJSONObject("serverContent") ?: return

                server.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                    for (i in 0 until parts.length()) {
                        val chunk = parts.optJSONObject(i)?.optString("text")
                        if (!chunk.isNullOrEmpty()) onAnswerChunk(chunk)
                    }
                }

                if (server.optBoolean("turnComplete", false)) {
                    onTurnComplete()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Cannot parse LiveQA message: $text", e)
            }
        }

        val ws = client.newWebSocket(
            Request.Builder().url("$WS?key=$key").build(),
            object : WebSocketListener() {

                override fun onOpen(webSocket: WebSocket, response: Response) {
                    socket = webSocket
                    connected = true
                    setupReady = false

                    val setup = JSONObject()
                        .put(
                            "setup",
                            JSONObject()
                                .put("model", "models/gemini-3.5-live")
                                .put(
                                    "generationConfig",
                                    JSONObject().put("responseModalities", JSONArray().put("TEXT"))
                                )
                                .put(
                                    "systemInstruction",
                                    JSONObject().put(
                                        "parts",
                                        JSONArray().put(JSONObject().put("text", systemContext))
                                    )
                                )
                        )

                    Log.d(TAG, "LiveQA WebSocket opened; sending setup")
                    webSocket.send(setup.toString())
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    handleServerMessage(text)
                }

                override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) {
                    handleServerMessage(bytes.utf8())
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.e(TAG, "LiveQA failure HTTP=${response?.code}", t)
                    connected = false
                    setupReady = false
                    setupLatch?.countDown()
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "LiveQA closed code=$code reason=$reason")
                    connected = false
                    setupReady = false
                }
            }
        )

        socket = ws

        if (!latch.await(10, TimeUnit.SECONDS)) {
            Log.e(TAG, "LiveQA setup timeout")
            ws.cancel()
            socket = null
            connected = false
            setupReady = false
            return@withContext false
        }

        setupReady
    }

    fun sendAudio(chunk: ByteArray): Boolean {
        synchronized(sendLock) {
            val ws = socket ?: return false
            if (!connected || !setupReady) return false

            val message = JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put(
                        "audio",
                        JSONObject()
                            .put("mimeType", "audio/pcm;rate=16000")
                            .put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
                    )
                )

            return ws.send(message.toString())
        }
    }

    // Confirms the question (swipe-up) and asks the model to answer.
    fun endTurn(): Boolean {
        synchronized(sendLock) {
            val ws = socket ?: return false
            if (!connected || !setupReady) return false
            return ws.send(
                JSONObject()
                    .put("realtimeInput", JSONObject().put("audioStreamEnd", true))
                    .toString()
            )
        }
    }

    fun stop() {
        synchronized(sendLock) {
            socket?.close(1000, "qa done")
            socket = null
            connected = false
            setupReady = false
            setupLatch = null
        }
    }
}
