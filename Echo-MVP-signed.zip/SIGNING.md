# Echo signing

This project uses exactly two GitHub Actions secrets:

- `ECHO` — signing password and deterministic signing seed.
- `GEMINI` — Gemini API key.

The workflow creates the same signing keystore on every build from `ECHO`, so successive release APKs keep the same signing certificate and can be installed as updates over the previous APK (provided applicationId/package name remains unchanged).

Do not change the `ECHO` secret after installing a released APK, otherwise the signing certificate will change and Android will require uninstalling the old app before installing the new one.
