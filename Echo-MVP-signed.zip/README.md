# Эхо — MVP

Рабочая основа для тестирования: микрофон → Noise Suppressor → AGC → VAD → Gemini 3.5 Transcribe Live → карточка и PCM-аудио; локальная Room БД.

Secrets: `GEMINI`.

Workflow: `.github/workflows/build.yml`.

Примечание: этот MVP специально оставляет Live-диалог и ежедневную экстракцию памяти отдельным следующим этапом, чтобы не выдавать незавершённую интеграцию за готовую.
