package com.echo.app

import android.app.*
import android.content.*
import android.media.*
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

class ListeningService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false

    // One Room card per VAD speech stream.
    private var activeCardId: Long = 0L
    private var activeAudioFile: File? = null
    private var activeAudioOut: FileOutputStream? = null
    private val pendingTranscriptCards = java.util.concurrent.ConcurrentLinkedQueue<Long>()

    // Guards against a card being finalized twice (real transcript racing a timeout).
    private val finalizedCards = java.util.concurrent.ConcurrentHashMap.newKeySet<Long>()

    // How long we wait for Gemini to answer before assuming a card wasn't real
    // speech (a finger snap, a notification chime, a sound the phone itself made).
    private val NON_SPEECH_TIMEOUT_MS = 8000L

    // 20 ms recorder frames are accumulated into ~100 ms Gemini chunks.
    private val sendBatch = ArrayList<ByteArray>(5)

    override fun onCreate() {
        super.onCreate()
        startForeground(7, notification())
    }

    private fun notification(): Notification {
        val ch = NotificationChannel("echo", "Эхо", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)

        return Notification.Builder(this, "echo")
            .setContentTitle("Эхо слушает")
            .setContentText("Фоновое распознавание включено")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            running = false
            Gemini.stopLive()
            stopSelf()
        } else if (!running) {
            running = true
            listen()
        }
        return START_NOT_STICKY
    }

    private val onFinalTranscript: (String) -> Unit = { finalText ->
        val cardId = pendingTranscriptCards.poll()
        if (cardId != null) {
            finalizeCard(cardId, finalText)
        }
    }

    // Blank/absent transcript means Gemini didn't hear actual speech in that
    // clip (a click, a notification sound, noise the VAD misfired on) -- such
    // cards are removed instead of being shown to the user forever stuck on
    // "Расшифровка...".
    private fun finalizeCard(cardId: Long, text: String) {
        if (!finalizedCards.add(cardId)) return // already handled once

        scope.launch {
            val dao = EchoDb.get(this@ListeningService).cards()
            if (text.isBlank()) {
                val card = dao.byId(cardId)
                card?.audioPath?.let { try { File(it).delete() } catch (_: Exception) {} }
                dao.delete(cardId)
                Log.d("EchoService", "Dropped non-speech card=$cardId (no transcript)")
            } else {
                dao.updateText(cardId, text)
                Log.d("EchoService", "Saved final transcript for card=$cardId: $text")
            }
        }
    }

    // Backstop for clips Gemini never bothers to answer at all (pure noise).
    private fun scheduleNonSpeechTimeout(cardId: Long) {
        scope.launch {
            delay(NON_SPEECH_TIMEOUT_MS)
            if (pendingTranscriptCards.remove(cardId)) {
                finalizeCard(cardId, "")
            }
        }
    }

    // gemini-3.5-transcribe-live closes every session after ~10 minutes.
    // Called between phrases (never mid-speech) so a long background
    // listening session keeps transcribing instead of silently going dark.
    private suspend fun renewLiveSessionIfNeeded() {
        if (!Gemini.isConnected() || Gemini.needsRenewal()) {
            Log.d("EchoService", "Renewing Gemini Live session")
            Gemini.stopLive()
            if (!Gemini.startLive(onFinalTranscript)) {
                Log.e("EchoService", "Live session renewal failed; will retry")
            }
        }
    }

    private fun listen() {
        scope.launch {
            val liveReady = Gemini.startLive(onFinalTranscript)

            if (!liveReady) {
                Log.e("EchoService", "Could not establish persistent Gemini Live session")
                running = false
                return@launch
            }

            val minBuffer = AudioRecord.getMinBufferSize(
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val bufferBytes = maxOf(6400, minBuffer)
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferBytes
            )

            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                Gemini.stopLive()
                running = false
                return@launch
            }

            val ns = if (NoiseSuppressor.isAvailable()) {
                NoiseSuppressor.create(ar.audioSessionId)
            } else null

            val agc = if (AutomaticGainControl.isAvailable()) {
                AutomaticGainControl.create(ar.audioSessionId)
            } else null

            val buf = ShortArray(320) // 20 ms @ 16 kHz
            val ring = ArrayDeque<ByteArray>()
            var speech = false
            var silentChunks = 0

            try {
                ar.startRecording()

                while (running) {
                    val n = ar.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                    if (n <= 0) continue

                    val bytes = ByteArray(n * 2)
                    var sum = 0.0

                    for (k in 0 until n) {
                        val sample = buf[k].toInt()
                        bytes[k * 2] = (sample and 0xff).toByte()
                        bytes[k * 2 + 1] = (sample shr 8).toByte()
                        val normalized = sample / 32768.0
                        sum += normalized * normalized
                    }

                    ring.addLast(bytes)
                    while (ring.size > 20) ring.removeFirst() // 400 ms pre-roll

                    val rms = sqrt(sum / n)
                    val voice = rms > 0.012

                    // Only safe to swap the Live session between phrases.
                    if (!speech) {
                        renewLiveSessionIfNeeded()
                    }

                    if (voice) {
                        if (!speech) {
                            speech = true
                            silentChunks = 0

                            // Create exactly one card for this speech stream.
                            activeAudioFile = File(
                                filesDir,
                                "audio_${System.currentTimeMillis()}.pcm"
                            )
                            activeAudioOut = FileOutputStream(activeAudioFile)

                            activeCardId = EchoDb.get(this@ListeningService)
                                .cards()
                                .insert(
                                    SpeechCard(
                                        createdAt = System.currentTimeMillis(),
                                        text = "Расшифровка...",
                                        audioPath = activeAudioFile!!.absolutePath
                                    )
                                )

                            Log.d("EchoService", "Started card=$activeCardId")

                            // Send the 400 ms pre-roll, preserving the beginning of the phrase.
                            for (pre in ring) {
                                sendRealtimeChunk(pre)
                            }

                            // Write pre-roll once, through the same persistent stream
                            // used for the rest of the phrase (see appendAndSend).
                            ring.forEach { activeAudioOut?.write(it) }
                        }

                        appendAndSend(bytes)
                        silentChunks = 0

                    } else if (speech) {
                        appendAndSend(bytes)
                        silentChunks++

                        // 800 ms silence closes the speech stream.
                        if (silentChunks >= 40) {
                            speech = false
                            silentChunks = 0

                            flushSendBatch()
                            pendingTranscriptCards.add(activeCardId)
                            scheduleNonSpeechTimeout(activeCardId)
                            Gemini.endSpeech()

                            try { activeAudioOut?.close() } catch (_: Exception) {}
                            Log.d("EchoService", "Ended card=$activeCardId; waiting for final transcript")
                            activeCardId = 0L
                            activeAudioFile = null
                            activeAudioOut = null
                        }
                    }
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
                ns?.release()
                agc?.release()
                try { activeAudioOut?.close() } catch (_: Exception) {}
                activeAudioOut = null
                Gemini.stopLive()
            }
        }
    }

    private fun appendAndSend(bytes: ByteArray) {
        try {
            activeAudioOut?.write(bytes)
        } catch (e: Exception) {
            Log.e("EchoService", "Failed writing audio to disk", e)
        }

        sendBatch.add(bytes)
        if (sendBatch.size >= 5) {
            flushSendBatch()
        }
    }

    private fun sendRealtimeChunk(bytes: ByteArray) {
        sendBatch.add(bytes)
        if (sendBatch.size >= 5) flushSendBatch()
    }

    private fun flushSendBatch() {
        if (sendBatch.isEmpty()) return

        val total = sendBatch.sumOf { it.size }
        val merged = ByteArray(total)
        var offset = 0

        for (part in sendBatch) {
            part.copyInto(merged, offset)
            offset += part.size
        }

        if (!Gemini.sendAudio(merged)) {
            Log.e("EchoService", "Failed to send audio batch to persistent Gemini session")
        }

        sendBatch.clear()
    }

    override fun onDestroy() {
        running = false
        Gemini.stopLive()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
