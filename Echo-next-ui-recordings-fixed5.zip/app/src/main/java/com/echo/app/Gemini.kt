package com.echo.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Gemini {

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    suspend fun transcribe(chunks: List<ByteArray>): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank() || chunks.isEmpty()) return@withContext ""

        val result = StringBuilder()
        val opened = CountDownLatch(1)
        val setupDone = CountDownLatch(1)
        val finished = CountDownLatch(1)

        val socket = client.newWebSocket(
            Request.Builder().url("$WS?key=$key").build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                    opened.countDown()

                    val setup = JSONObject()
                        .put(
                            "setup",
                            JSONObject()
                                .put("model", "models/gemini-3.5-transcribe-live")
                                .put(
                                    "generationConfig",
                                    JSONObject().put(
                                        "responseModalities",
                                        JSONArray().put("TEXT")
                                    )
                                )
                                .put(
                                    "realtimeInputConfig",
                                    JSONObject().put(
                                        "automaticActivityDetection",
                                        JSONObject().put("disabled", true)
                                    )
                                )
                                .put(
                                    "inputAudioTranscription",
                                    JSONObject()
                                        .put("languageCodes", JSONArray())
                                        .put("mode", "SMART")
                                )
                        )

                    if (!webSocket.send(setup.toString())) {
                        setupDone.countDown()
                        finished.countDown()
                    }
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val json = JSONObject(text)

                        if (json.has("setupComplete")) {
                            setupDone.countDown()
                        }

                        val server = json.optJSONObject("serverContent") ?: return

                        server.optJSONObject("inputTranscription")
                            ?.optString("text")
                            ?.takeIf { it.isNotBlank() }
                            ?.let {
                                synchronized(result) {
                                    result.append(it).append(' ')
                                }
                            }

                        if (server.optBoolean("turnComplete", false)) {
                            finished.countDown()
                        }
                    } catch (e: Exception) {
                        Log.e("EchoGemini", "Live response parse error: $text", e)
                    }
                }

                override fun onFailure(
                    webSocket: WebSocket,
                    t: Throwable,
                    response: okhttp3.Response?
                ) {
                    Log.e(
                        "EchoGemini",
                        "WebSocket failed HTTP=${response?.code}",
                        t
                    )
                    opened.countDown()
                    setupDone.countDown()
                    finished.countDown()
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    finished.countDown()
                }
            }
        )

        if (!opened.await(8, TimeUnit.SECONDS)) {
            socket.cancel()
            return@withContext ""
        }
        if (!setupDone.await(8, TimeUnit.SECONDS)) {
            socket.cancel()
            return@withContext ""
        }

        // The app already has its own VAD. Use explicit activity boundaries
        // instead of relying on the server to infer the end of the turn.
        socket.send(
            JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put("activityStart", JSONObject())
                )
                .toString()
        )

        // Google recommends sending Live transcription audio in roughly 100 ms chunks.
        // Our recorder produces 20 ms chunks, so combine five chunks before sending.
        val batch = ArrayList<ByteArray>(5)
        for (chunk in chunks) {
            batch.add(chunk)
            if (batch.size == 5) {
                val total = batch.sumOf { it.size }
                val merged = ByteArray(total)
                var offset = 0
                for (part in batch) {
                    part.copyInto(merged, offset)
                    offset += part.size
                }

                val message = JSONObject()
                    .put(
                        "realtimeInput",
                        JSONObject().put(
                            "audio",
                            JSONObject()
                                .put("mimeType", "audio/pcm;rate=16000")
                                .put("data", Base64.encodeToString(merged, Base64.NO_WRAP))
                        )
                    )

                if (!socket.send(message.toString())) {
                    Log.e("EchoGemini", "WebSocket refused audio")
                    break
                }
                batch.clear()
                Thread.sleep(100)
            }
        }

        if (batch.isNotEmpty()) {
            val total = batch.sumOf { it.size }
            val merged = ByteArray(total)
            var offset = 0
            for (part in batch) {
                part.copyInto(merged, offset)
                offset += part.size
            }
            socket.send(
                JSONObject()
                    .put(
                        "realtimeInput",
                        JSONObject().put(
                            "audio",
                            JSONObject()
                                .put("mimeType", "audio/pcm;rate=16000")
                                .put("data", Base64.encodeToString(merged, Base64.NO_WRAP))
                        )
                    )
                    .toString()
            )
        }

        socket.send(
            JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put("activityEnd", JSONObject())
                )
                .toString()
        )

        finished.await(15, TimeUnit.SECONDS)
        Thread.sleep(500)
        socket.close(1000, "turn complete")

        synchronized(result) { result.toString().trim() }
    }

    suspend fun extract(prompt: String): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank()) return@withContext ""

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json")
            )

        val request = Request.Builder()
            .url(
                "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "gemini-3.5-flash-lite:generateContent?key=$key"
            )
            .post(
                body.toString()
                    .toRequestBody("application/json".toMediaType())
            )
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e("EchoGemini", "HTTP ${response.code}: ${response.body?.string()}")
                return@withContext ""
            }

            val responseBody = response.body?.string() ?: return@withContext ""
            val json = JSONObject(responseBody)

            json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}
