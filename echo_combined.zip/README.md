# Echo — combined phone + Wear OS bundle

This archive contains the phone app and Wear OS companion in two independent Gradle projects:

- `echo_project/` — Android phone app
- `echo_wear/` — Wear OS app

For the test build, both APKs are signed in the same GitHub Actions run with one freshly generated temporary JKS key.
The same alias (`echo`) and the same password (`ECHO`) are used for both APKs.

Important: the temporary signing key is regenerated on every workflow run. APKs from different runs will therefore have different signing certificates and cannot update-install over one another. This is intentional for a clean test build.
