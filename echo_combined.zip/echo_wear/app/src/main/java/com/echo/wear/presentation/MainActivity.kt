package com.echo.wear.presentation

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.app.ActivityCompat
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import com.echo.wear.bridge.MicSource
import com.echo.wear.bridge.PhoneBridge
import com.echo.wear.bridge.WatchCard
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
        PhoneBridge.init(this)
        setContent {
            MaterialTheme {
                EchoWearRoot()
            }
        }
    }

    override fun onDestroy() {
        PhoneBridge.dispose(this)
        super.onDestroy()
    }
}

/* —— palette —— */
private val Bg = Color(0xFF07080B)
private val CardBg = Color(0xFF2A2E36)      // dark gray cards
private val Accent = Color(0xFF6EA8FF)
private val Danger = Color(0xFFFF3B4A)
private val TextPrimary = Color(0xFFF2F4F8)
private val Muted = Color(0xFF8B91A0)
private val LiveWhite = Color(0xFFF5F5F7)
private val LiveText = Color(0xFF111318)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EchoWearRoot() {
    val pagerState = rememberPagerState(pageCount = { 3 })
    // Local demo state until phone sync is wired
    var listening by remember { mutableStateOf(false) }
    var liveActive by remember { mutableStateOf(false) }
    var liveStatus by remember { mutableStateOf("Подключаюсь…") }
    var liveSubtitles by remember { mutableStateOf("") }
    var micSource by remember { mutableStateOf(MicSource.WATCH) }
    var phoneConnected by remember { mutableStateOf(PhoneBridge.isConnected) }
    val cards = remember { mutableStateListOf<WatchCard>() }
    LaunchedEffect(Unit) {
        PhoneBridge.onCards = { list ->
            cards.clear()
            cards.addAll(list)
        }
        PhoneBridge.onConnectionChanged = { connected ->
            phoneConnected = connected
        }
        phoneConnected = PhoneBridge.isConnected
        PhoneBridge.requestCards()
        // seed cache if already loaded
        val cached = PhoneBridge.cachedCards()
        if (cached.isNotEmpty()) {
            cards.clear()
            cards.addAll(cached)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            // Full-screen pages, swipe anywhere — no indicators, no nav bar
            userScrollEnabled = !liveActive
        ) { page ->
            when (page) {
                0 -> ControlPage(
                    listening = listening,
                    liveActive = liveActive,
                    liveStatus = liveStatus,
                    liveSubtitles = liveSubtitles,
                    phoneConnected = phoneConnected,
                    onToggleListen = {
                        if (!phoneConnected && !listening) {
                            // не даём «включить» без связи — покажем статус
                            liveStatus = "Нет связи с телефоном"
                        } else {
                            listening = !listening
                            if (listening) {
                                PhoneBridge.startListen(micSource)
                            } else {
                                PhoneBridge.stopListen()
                            }
                        }
                    },
                    onStartLive = {
                        if (!phoneConnected) {
                            liveStatus = "Нет связи с телефоном"
                        } else {
                            liveActive = true
                            liveStatus = "Подключаюсь…"
                            liveSubtitles = ""
                            listening = false
                            PhoneBridge.stopListen()
                            PhoneBridge.startLive(
                                onStatus = { s ->
                                    liveStatus = s
                                    if (s == "Нет связи с телефоном") {
                                        liveActive = false
                                    }
                                },
                                onSubtitle = { liveSubtitles += it },
                                mutePhoneAudio = true
                            )
                        }
                    },
                    onStopLive = {
                        liveActive = false
                        liveSubtitles = ""
                        PhoneBridge.stopLive()
                    }
                )
                1 -> CardsPage(
                    cards = cards,
                    onToggleFavorite = { id ->
                        val i = cards.indexOfFirst { it.id == id }
                        if (i >= 0) {
                            cards[i] = cards[i].copy(favorite = !cards[i].favorite)
                            PhoneBridge.setFavorite(id, cards[i].favorite)
                        }
                    }
                )
                2 -> MicSourcePage(
                    selected = micSource,
                    onSelect = {
                        micSource = it
                        PhoneBridge.setMicSource(it)
                    }
                )
            }
        }
    }
}

/* ═══════════════ Screen 1: control / Live ═══════════════ */

@Composable
private fun ControlPage(
    listening: Boolean,
    liveActive: Boolean,
    liveStatus: String,
    liveSubtitles: String,
    phoneConnected: Boolean,
    onToggleListen: () -> Unit,
    onStartLive: () -> Unit,
    onStopLive: () -> Unit
) {
    if (liveActive) {
        LiveSessionScreen(
            status = liveStatus,
            subtitles = liveSubtitles,
            onTapEnd = onStopLive
        )
        return
    }

    val view = LocalView.current
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = if (listening) 1.08f else 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (listening) 850 else 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Bg),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(
                    id = if (listening) com.echo.wear.R.drawable.ic_fab_listening 
                         else com.echo.wear.R.drawable.ic_fab_idle
                ),
                contentDescription = if (listening) "Запись" else "Ожидание",
                modifier = Modifier
                    .size(76.dp)
                    .scale(scale)
                    .pointerInput(listening) {
                        detectTapGestures(
                            onTap = {
                                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                                onToggleListen()
                            },
                            onLongPress = {
                                view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                onStartLive()
                            }
                        )
                    }
            )

            Spacer(Modifier.height(14.dp))

            Text(
                text = when {
                    !phoneConnected -> "Нет связи"
                    listening -> "Слушает"
                    else -> "Готов"
                },
                color = if (!phoneConnected) Danger else TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = when {
                    !phoneConnected -> "Открой Эхо на телефоне"
                    listening -> "Тап — стоп"
                    else -> "Удерж. — Live"
                },
                color = Muted,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun LiveSessionScreen(
    status: String,
    subtitles: String,
    onTapEnd: () -> Unit
) {
    val scroll = rememberScrollState()
    LaunchedEffect(subtitles) {
        if (subtitles.isNotEmpty()) {
            scroll.animateScrollTo(scroll.maxValue)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(LiveWhite)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onTapEnd() })
            }
            .padding(horizontal = 14.dp, vertical = 18.dp)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(scroll),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = status,
                color = Muted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            if (subtitles.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = subtitles,
                    color = LiveText,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Тап — закрыть",
                color = Muted.copy(alpha = 0.7f),
                fontSize = 10.sp
            )
        }
    }
}

/* ═══════════════ Screen 2: cards ═══════════════ */

@Composable
private fun CardsPage(
    cards: List<WatchCard>,
    onToggleFavorite: (Long) -> Unit
) {
    val view = LocalView.current
    val scroll = rememberScrollState()

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(scroll)
            .padding(horizontal = 10.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (cards.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                Text("Нет записей", color = Muted, fontSize = 13.sp)
            }
        } else {
            cards.forEach { card ->
                CardItem(card) {
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onToggleFavorite(card.id)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun CardItem(card: WatchCard, onLongPress: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .pointerInput(card.id) {
                detectTapGestures(onLongPress = { onLongPress() })
            }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            text = buildString {
                append(card.time)
                if (card.favorite) append("  ★")
            },
            color = Muted,
            fontSize = 10.sp
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = card.text,
            color = TextPrimary,
            fontSize = 13.sp,
            maxLines = 6,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 16.sp
        )
    }
}

/* ═══════════════ Screen 3: mic source ═══════════════ */

@Composable
private fun MicSourcePage(
    selected: MicSource,
    onSelect: (MicSource) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(horizontal = 12.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Микрофон",
            color = Muted,
            fontSize = 11.sp
        )
        Spacer(Modifier.height(10.dp))
        MicOption(
            title = "Часы",
            subtitle = "Фон — с запястья",
            selected = selected == MicSource.WATCH
        ) { onSelect(MicSource.WATCH) }
        Spacer(Modifier.height(8.dp))
        MicOption(
            title = "Телефон",
            subtitle = "Фон — с телефона",
            selected = selected == MicSource.PHONE
        ) { onSelect(MicSource.PHONE) }
    }
}

@Composable
private fun MicOption(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val view = LocalView.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) CardBg.copy(alpha = 1f) else CardBg.copy(alpha = 0.65f))
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onClick()
                })
            }
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(
            text = if (selected) "●  $title" else "○  $title",
            color = if (selected) Accent else TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}
