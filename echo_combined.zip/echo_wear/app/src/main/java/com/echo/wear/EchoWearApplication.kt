package com.echo.wear

import android.app.Application
import com.google.android.gms.wearable.Wearable

class EchoWearApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            Wearable.getCapabilityClient(this)
                .addLocalCapability("echo_watch")
        } catch (_: Exception) {
            // Data Layer may be temporarily unavailable; it can recover on next process start.
        }
    }
}
