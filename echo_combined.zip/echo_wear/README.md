# Эхо — Galaxy Watch 8 (40mm)

Companion: интернет и база на телефоне.

## Экраны (свайп, без навбара)

1. **Кнопка** — тап: фон.запись · long-press: Live (белый, статус→субтитры, без звука)
2. **Карточки** — синк с телефона, ★ long-press
3. **Микрофон** — часы / телефон (фон)

## Мост

`PhoneBridge` ↔ `WearBridgeService` (phone):

| Path | Назначение |
|------|------------|
| `/echo/listen/start\|stop` | фон |
| `/echo/live/start\|stop\|audio` | Live, PCM с часов |
| `/echo/live/status\|subtitle` | UI на часах |
| `/echo/cards` | лента |
| `/echo/cards/favorite` | ★ |
| `/echo/mic` | источник мика |

Live: мик часов → телефон → Gemini; ответ только субтитрами, **без playback**.

## Сборка

```bash
./gradlew :app:assembleDebug
```


## Исправление связи
Capability `echo_watch` теперь публикуется из `Application`, а не из Activity, поэтому связь не исчезает при уничтожении/пересоздании экрана.
