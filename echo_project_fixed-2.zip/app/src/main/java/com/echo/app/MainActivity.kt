package com.echo.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var cards: LinearLayout
    private lateinit var brandTitle: TextView
    private lateinit var searchField: EditText
    private var selectedTab = 0
    private var currentSearchQuery = ""
    private val navLabels = mutableListOf<TextView>()

    // Quiet dark palette — soft depth, cool accent, high readability
    private val bg = Color.parseColor("#07080B")
    private val panel = Color.parseColor("#12141A")
    private val panelElevated = Color.parseColor("#1A1D26")
    private val stroke = Color.parseColor("#2A2E3A")
    private val primaryText = Color.parseColor("#F2F4F8")
    private val muted = Color.parseColor("#8B91A0")
    private val accent = Color.parseColor("#6EA8FF")
    private val accentSoft = Color.parseColor("#1A2A44")
    private val danger = Color.parseColor("#FF6B7A")
    private val success = Color.parseColor("#5CDBA0")

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }

        buildUi()
        refreshLoop()
        DigestAlarmReceiver.schedule(this)

        lifecycleScope.launch {
            MemoryExtraction.runIfDue(this@MainActivity)
            if (selectedTab == 1) loadMemory()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(
        color: Int,
        radius: Int = 18,
        strokeColor: Int? = null,
        strokeWidthDp: Int = 1
    ): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeColor != null) {
                setStroke(dp(strokeWidthDp), strokeColor)
            }
        }

    private fun label(value: String, size: Float, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            includeFontPadding = false
            letterSpacing = 0.01f
        }

    private fun sectionTitle(value: String): TextView =
        label(value.uppercase(Locale.getDefault()), 11f, accent).apply {
            letterSpacing = 0.12f
            setPadding(dp(4), dp(4), dp(4), dp(8))
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }

    private fun primaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            letterSpacing = 0.04f
            background = rounded(accent, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun secondaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(primaryText)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            background = rounded(panelElevated, 14, stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            setBackgroundColor(bg)
        }

        // —— Header ——
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        brandTitle = label("Эхо", 28f, primaryText).apply {
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            letterSpacing = -0.02f
        }
        topRow.addView(brandTitle, LinearLayout.LayoutParams(0, -2, 1f))

        // Live status pill
        status = label("Готово", 12f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(panelElevated, 20, stroke)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        topRow.addView(status, LinearLayout.LayoutParams(-2, -2))
        header.addView(topRow)

        searchField = EditText(this).apply {
            hint = "Поиск по всем записям"
            setHintTextColor(Color.parseColor("#5C6370"))
            setTextColor(primaryText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(panel, 16, stroke)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val query = s?.toString()?.trim() ?: ""
                    currentSearchQuery = query
                    filterCards(query)
                }
            })
        }
        header.addView(searchField, LinearLayout.LayoutParams(-1, dp(48)).apply {
            topMargin = dp(14)
        })

        root.addView(header)

        // —— Content ——
        val content = FrameLayout(this)
        cards = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, dp(100))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(cards)
        }
        content.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // —— FAB ——
        val fab = TextView(this).apply {
            text = "●"
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            background = rounded(accent, 50)
            elevation = dp(10).toFloat()
        }
        attachFabGesture(fab)
        val fabParams = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabParams.bottomMargin = dp(72)
        content.addView(fab, fabParams)

        // —— Bottom nav ——
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(14))
            background = ColorDrawableCompat(panel)
        }

        navLabels.clear()
        listOf("Лента" to 0, "Память" to 1, "Настройки" to 2).forEach { (title, tab) ->
            val item = navItem(title, tab)
            navLabels.add(item)
            nav.addView(item, LinearLayout.LayoutParams(0, dp(44), 1f))
        }

        root.addView(nav)
        setContentView(root)
        selectTab(0)
    }

    private fun navItem(title: String, tab: Int): TextView =
        label(title, 13f, muted).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { selectTab(tab) }
        }

    private fun updateNavSelection() {
        navLabels.forEachIndexed { index, tv ->
            val active = index == selectedTab
            tv.setTextColor(if (active) primaryText else muted)
            tv.background = if (active) rounded(accentSoft, 12) else null
        }
    }

    private fun selectTab(tab: Int) {
        selectedTab = tab
        updateNavSelection()
        when (tab) {
            0 -> {
                searchField.visibility = View.VISIBLE
                setStatusPill(
                    if (getPreferences(0).getBoolean("running", false)) "Слушает" else "Готово",
                    listening = getPreferences(0).getBoolean("running", false)
                )
                if (currentSearchQuery.isBlank()) loadCards() else filterCards(currentSearchQuery)
            }
            1 -> {
                searchField.visibility = View.GONE
                setStatusPill("Память", listening = false)
                loadMemory()
            }
            2 -> {
                searchField.visibility = View.GONE
                setStatusPill("Настройки", listening = false)
                cards.removeAllViews()
                addSetting("Аудио", "Оригинальные записи хранятся 72 часа")
                addSetting("Поиск", "Контекст последней недели")
                addSetting("Язык", "Определяется автоматически")
                addSetting("Модель", "Gemini Live · Эхо")
            }
        }
    }

    private fun setStatusPill(text: String, listening: Boolean) {
        status.text = if (listening) "●  $text" else text
        status.setTextColor(if (listening) accent else muted)
        status.background = rounded(
            if (listening) accentSoft else panelElevated,
            20,
            if (listening) accent else stroke
        )
    }

    private fun addEmpty(message: String) {
        cards.addView(label(message, 15f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(48), dp(12), dp(48))
            lineSpacingMultiplier = 1.25f
        })
    }

    private fun addSetting(title: String, subtitle: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 16, stroke)
        }
        row.addView(label(title, 15f, primaryText).apply {
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        })
        row.addView(label(subtitle, 13f, muted).apply {
            setPadding(0, dp(4), 0, 0)
            lineSpacingMultiplier = 1.2f
        })
        cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })
    }

    private fun loadCards() {
        lifecycleScope.launch {
            val list = EchoDb.get(this@MainActivity).cards().all()
            cards.removeAllViews()
            if (list.isEmpty()) {
                addEmpty("Пока нет записей.\nНажми ● и начни говорить.")
                return@launch
            }
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            list.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(15))
                    background = rounded(panel, 16, stroke)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    lineSpacingMultiplier = 1.28f
                })
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    private fun loadMemory() {
        cards.removeAllViews()
        addDaySummarySection()
        addMemoryRefreshButton()

        lifecycleScope.launch {
            val facts = EchoDb.get(this@MainActivity).memory().all()
            if (facts.isEmpty()) {
                addEmpty("Здесь появятся устойчивые факты, которые Эхо запомнило.")
                return@launch
            }

            var lastCategory = ""
            facts.forEach { f ->
                if (f.category != lastCategory) {
                    lastCategory = f.category
                    cards.addView(sectionTitle(f.category.replaceFirstChar { it.uppercase() }))
                }
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(panel, 16, stroke)
                }
                row.addView(label(f.subject, 12f, muted).apply {
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                })
                row.addView(label(f.fact, 15f, primaryText).apply {
                    setPadding(0, dp(6), 0, 0)
                    lineSpacingMultiplier = 1.25f
                })
                cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
            }
        }
    }

    // "Анализ дня" -- an artistic recap of today's cards, sitting above the
    // long-term memory list. Shows the cached digest instantly (if any) while
    // a fresh one is fetched in the background, throttled to once an hour.
    private fun addDaySummarySection() {
        cards.addView(sectionTitle("Анализ дня"))

        val body = label("Собираю впечатления за сегодня...", 15f, primaryText).apply {
            lineSpacingMultiplier = 1.3f
        }
        val caption = label("", 11f, muted).apply { setPadding(0, dp(10), 0, 0) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 16, stroke)
        }
        card.addView(body)
        card.addView(caption)
        cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(20)
        })

        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        fun show(result: DaySummary.Result) {
            body.text = result.text
            caption.text = "Обновлено в ${timeFmt.format(Date(result.generatedAt))}" +
                if (result.isFinal) " · итог дня зафиксирован" else ""
        }

        lifecycleScope.launch {
            // Avoid a "Собираю..." flash on every reopen if we already have something.
            val cachedResult = DaySummary.cached(this@MainActivity)
            cachedResult?.let { show(it) }

            val result = DaySummary.runIfDue(this@MainActivity)
            if (result != null) {
                show(result)
            } else if (cachedResult == null) {
                body.text = "Пока рановато подводить итоги — скажи что-нибудь вслух."
                caption.text = ""
            }
        }
    }

    private fun addMemoryRefreshButton() {
        val btn = secondaryButton("Обновить память") {}
        btn.setOnClickListener {
            btn.isEnabled = false
            (btn as TextView).text = "Извлекаю факты..."
            lifecycleScope.launch {
                val added = MemoryExtraction.runNow(this@MainActivity)
                Toast.makeText(
                    this@MainActivity,
                    if (added > 0) "Новых фактов: $added" else "Новых фактов не найдено",
                    Toast.LENGTH_SHORT
                ).show()
                if (selectedTab == 1) loadMemory()
            }
        }
        cards.addView(btn, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(18)
            topMargin = dp(4)
        })
    }

    // Tap = play back the recording (tap again while it's playing = stop it),
    // long-press = copy the text, swipe left = delete the card + its audio,
    // swipe right = toggle favorite (snaps back, doesn't remove the card).
    private fun attachCardGestures(view: View, card: SpeechCard, star: TextView) {
        var isFavorite = card.favorite

        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (playingCardId == card.id && isPlaying) {
                    stopPlayback()
                } else {
                    playCard(card)
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Эхо", card.text))
                Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
            }
        })

        var downX = 0f
        var downY = 0f
        var dragging = false

        view.setOnTouchListener { v, event ->
            gesture.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!dragging && abs(dx) > dp(16) && abs(dx) > abs(dy)) {
                        dragging = true
                        v.parent.requestDisallowInterceptTouchEvent(true)
                    }
                    if (dragging) {
                        v.translationX = dx
                        // Fade only previews the delete (left) direction.
                        v.alpha = if (dx < 0) {
                            1f - (-dx / v.width.coerceAtLeast(1)).coerceIn(0f, 0.8f)
                        } else 1f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        val dx = event.rawX - downX
                        when {
                            dx < -v.width * 0.35f -> {
                                v.animate().translationX(-v.width.toFloat()).alpha(0f)
                                    .setDuration(180)
                                    .withEndAction { deleteCard(card, v) }
                                    .start()
                            }
                            dx > v.width * 0.35f -> {
                                isFavorite = !isFavorite
                                star.text = if (isFavorite) "★" else ""
                                lifecycleScope.launch {
                                    EchoDb.get(this@MainActivity).cards().setFavorite(card.id, isFavorite)
                                }
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                            else -> {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                        }
                    }
                    dragging = false
                    true
                }
                else -> true
            }
        }
    }

    private fun deleteCard(card: SpeechCard, view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
        stopPlayback()
        lifecycleScope.launch {
            EchoDb.get(this@MainActivity).cards().delete(card.id)
            card.audioPath?.let { path -> try { File(path).delete() } catch (_: Exception) {} }
        }
    }

    // Raw 16 kHz / mono / 16-bit PCM playback of a card's saved recording.
    private var playThread: Thread? = null
    @Volatile private var isPlaying = false
    @Volatile private var playingCardId: Long? = null

    private fun playCard(card: SpeechCard) {
        val path = card.audioPath
        if (path == null) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists() || file.length() == 0L) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }

        stopPlayback()
        isPlaying = true
        playingCardId = card.id
        playThread = Thread {
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    16000,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 4096),
                    AudioTrack.MODE_STREAM
                )
                track.play()
                file.inputStream().use { input ->
                    val buf = ByteArray(3200)
                    while (isPlaying) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        track.write(buf, 0, n)
                    }
                }
                track.stop()
                track.release()
            } catch (e: Exception) {
                android.util.Log.e("EchoPlayback", "Playback failed", e)
            } finally {
                isPlaying = false
                if (playingCardId == card.id) playingCardId = null
            }
        }
        playThread?.start()
    }

    private fun stopPlayback() {
        isPlaying = false
        try { playThread?.join(200) } catch (_: Exception) {}
        playThread = null
        playingCardId = null
    }

    override fun onStop() {
        stopPlayback()
        if (qaActive) stopLiveQA()
        super.onStop()
    }

    private fun refreshLoop() {
        lifecycleScope.launch {
            while (!isFinishing) {
                if (selectedTab == 0) {
                    // Don't wipe an active search result with a full reload.
                    if (currentSearchQuery.isBlank()) {
                        loadCards()
                    } else {
                        filterCards(currentSearchQuery)
                    }
                }
                delay(2500)
            }
        }
    }

    private fun toggle() {
        val running = getPreferences(0).getBoolean("running", false)
        val intent = Intent(this, ListeningService::class.java).apply {
            action = if (running) "stop" else "start"
        }
        if (running) {
            stopService(intent)
        } else {
            startForegroundService(intent)
        }
        getPreferences(0).edit().putBoolean("running", !running).apply()
        if (selectedTab == 0) {
            setStatusPill(if (running) "Готово" else "Слушает", listening = !running)
        }
    }

    // Long-press the FAB to open the overlay and start recording a spoken
    // question; swipe up (while still holding) to send it; releasing without
    // swiping up cancels. A plain tap still toggles background listening.
    private fun attachFabGesture(fab: View) {
        // Long-press opens a continuous Live QA session.
        // A second tap while the session is active closes it.
        // A plain short tap (no active QA) still toggles background listening.
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (qaActive) {
                    // Second tap — close the running session
                    stopLiveQA()
                } else {
                    toggle()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!qaActive) startLiveQA()
            }
        })

        fab.setOnTouchListener { _, event ->
            gesture.onTouchEvent(event)
            true
        }
    }

    @Volatile private var qaActive = false
    @Volatile private var qaRecording = false
    private var qaRecordThread: Thread? = null
    private var qaOverlay: View? = null
    private var qaStatus: TextView? = null
    private var qaAnswer: TextView? = null

    // Live QA model audio playback (Gemini Live returns 24 kHz PCM mono).
    private var qaTrack: AudioTrack? = null
    private val qaTrackLock = Any()

    // Two AudioRecord sessions on the mic at once is unreliable across
    // devices -- pause background listening while a question is being asked,
    // and always resume it (if it was running) once the overlay closes.
    private var qaPausedBackgroundListening = false

    private fun startLiveQA() {
        qaActive = true
        qaPausedBackgroundListening = getPreferences(0).getBoolean("running", false)
        if (qaPausedBackgroundListening) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
        }
        showQaOverlay()
        ensureQaTrack()

        lifecycleScope.launch {
            val context = LiveQaContext.build(this@MainActivity)
            val ready = LiveQA.start(
                systemContext = context,
                onAnswerChunk = { pcm ->
                    // Model audio: play PCM immediately (off the UI thread).
                    writeQaAudio(pcm)
                    runOnUiThread {
                        qaStatus?.text = "Эхо отвечает..."
                    }
                },
                onSubtitleChunk = { text ->
                    runOnUiThread {
                        qaAnswer?.append(text)
                    }
                },
                onTurnComplete = {
                    // Session stays open — ready for the next question
                    runOnUiThread { qaStatus?.text = "Слушаю... нажми ещё раз, чтобы закрыть" }
                }
            )
            if (!qaActive) return@launch
            if (!ready) {
                runOnUiThread { qaStatus?.text = "Не удалось подключиться к Эхо." }
                return@launch
            }
            runOnUiThread { qaStatus?.text = "Слушаю... нажми ещё раз, чтобы закрыть" }
            beginQaRecording()
        }
    }

    // Closes the ongoing Live QA session (triggered by second tap on FAB or ЗАКРЫТЬ button).
    private fun stopLiveQA() {
        qaActive = false
        qaRecording = false
        LiveQA.stop()
        releaseQaTrack()
        closeQaOverlay()
        if (qaPausedBackgroundListening) {
            qaPausedBackgroundListening = false
            startForegroundService(Intent(this, ListeningService::class.java).apply { action = "start" })
        }
    }

    private fun ensureQaTrack() {
        synchronized(qaTrackLock) {
            if (qaTrack != null) return
            // Gemini Live AUDIO modality delivers 24 kHz 16-bit mono PCM.
            val sampleRate = 24000
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4800),
                AudioTrack.MODE_STREAM
            )
            track.play()
            qaTrack = track
        }
    }

    private fun writeQaAudio(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        synchronized(qaTrackLock) {
            val track = qaTrack ?: return
            try {
                track.write(pcm, 0, pcm.size)
            } catch (e: Exception) {
                android.util.Log.e("EchoLiveQA", "writeQaAudio failed", e)
            }
        }
    }

    private fun releaseQaTrack() {
        synchronized(qaTrackLock) {
            try {
                qaTrack?.stop()
            } catch (_: Exception) {}
            try {
                qaTrack?.release()
            } catch (_: Exception) {}
            qaTrack = null
        }
    }

    private fun beginQaRecording() {
        qaRecording = true
        qaRecordThread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(6400, minBuf)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                return@Thread
            }
            ar.startRecording()
            try {
                val buf = ShortArray(320)
                while (qaRecording) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val s = buf[k].toInt()
                        bytes[k * 2] = (s and 0xff).toByte()
                        bytes[k * 2 + 1] = (s shr 8).toByte()
                    }
                    LiveQA.sendAudio(bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }
        qaRecordThread?.start()
    }

    // filterCards: re-renders the cards list filtered by query (case-insensitive substring match).
    // Empty query restores the full list for the current tab.
    private fun filterCards(query: String) {
        if (query.isEmpty()) {
            when (selectedTab) {
                0 -> loadCards()
                1 -> loadMemory()
            }
            return
        }
        lifecycleScope.launch {
            val db = EchoDb.get(this@MainActivity)
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            val lower = query.lowercase()
            val results = db.cards().all().filter { it.text.lowercase().contains(lower) }
            cards.removeAllViews()
            if (results.isEmpty()) {
                addEmpty("Ничего не найдено по запросу «$query»")
                return@launch
            }
            results.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(15))
                    background = rounded(panel, 16, stroke)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    lineSpacingMultiplier = 1.28f
                })
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    private fun showQaOverlay() {
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(40), dp(32), dp(40))
            setBackgroundColor(Color.argb(250, 7, 8, 11))
        }
        val title = label("Эхо", 22f, primaryText).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            letterSpacing = -0.01f
        }
        val pulse = label("●", 56f, accent).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(12))
        }
        val status = label("Подключаюсь...", 14f, muted).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        val answer = label("", 16f, primaryText).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(28), dp(8), 0)
            lineSpacingMultiplier = 1.35f
        }
        val close = primaryButton("Закрыть") { stopLiveQA() }

        overlay.addView(title)
        overlay.addView(pulse)
        overlay.addView(status)
        overlay.addView(answer)
        overlay.addView(close, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(36)
        })

        qaOverlay = overlay
        qaStatus = status
        qaAnswer = answer
        addContentView(overlay, ViewGroup.LayoutParams(-1, -1))
    }

    private fun closeQaOverlay() {
        (qaOverlay?.parent as? ViewGroup)?.removeView(qaOverlay)
        qaOverlay = null
        qaStatus = null
        qaAnswer = null
    }

    private object ColorDrawableCompat {
        operator fun invoke(color: Int) = android.graphics.drawable.ColorDrawable(color)
    }
}
