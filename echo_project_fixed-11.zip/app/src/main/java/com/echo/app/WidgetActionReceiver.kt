package com.echo.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        try {
            when (intent?.action) {
                ACTION_TOGGLE_LISTEN -> toggleListen(context)
                ACTION_START_LIVE -> startLive(context)
                ACTION_STOP_LIVE -> stopLive(context)
                WidgetUpdater.ACTION_TICK -> onTick(context)
            }
        } finally {
            pending.finish()
        }
    }

    private fun onTick(ctx: Context) {
        if (EchoState.isLive(ctx)) {
            EchoState.nextWaveFrame(ctx)
            WidgetUpdater.refreshAll(ctx)
        } else if (EchoState.isListening(ctx)) {
            val phase = EchoState.prefs(ctx).getInt("pulse_phase", 0) + 1
            EchoState.prefs(ctx).edit().putInt("pulse_phase", phase).apply()
            WidgetTransition.pulseListening(ctx, phase)
            // still refresh timer text every other pulse
            if (phase % 2 == 0) {
                WidgetUpdater.refreshAll(ctx)
            }
        }
        WidgetUpdater.scheduleTick(ctx)
    }

    private fun toggleListen(ctx: Context) {
        if (EchoState.isLive(ctx)) {
            stopLive(ctx)
            return
        }
        val on = !EchoState.isListening(ctx)
        EchoState.setListening(ctx, on)
        val i = Intent(ctx, ListeningService::class.java).apply {
            action = if (on) "start" else "stop"
        }
        if (on) ctx.startForegroundService(i) else ctx.stopService(i)
        WidgetTransition.animateModeChange(ctx)
        if (on) WidgetUpdater.scheduleTick(ctx)
        else if (!EchoState.isLive(ctx)) WidgetUpdater.cancelTick(ctx)
    }

    private fun startLive(ctx: Context) {
        if (EchoState.isLive(ctx)) return
        if (EchoState.isListening(ctx)) {
            ctx.stopService(Intent(ctx, ListeningService::class.java).apply { action = "stop" })
            EchoState.setListening(ctx, false)
        }
        EchoState.setLive(ctx, true, "Подключаюсь…")
        WidgetTransition.animateModeChange(ctx)
        WidgetUpdater.scheduleTick(ctx)
        ctx.startForegroundService(Intent(ctx, WidgetLiveService::class.java).apply { action = "start" })
    }

    private fun stopLive(ctx: Context) {
        ctx.stopService(Intent(ctx, WidgetLiveService::class.java).apply { action = "stop" })
        EchoState.setLive(ctx, false)
        WidgetTransition.animateModeChange(ctx)
        if (EchoState.isListening(ctx)) WidgetUpdater.scheduleTick(ctx)
        else WidgetUpdater.cancelTick(ctx)
    }

    companion object {
        const val ACTION_TOGGLE_LISTEN = "com.echo.app.WIDGET_TOGGLE_LISTEN"
        const val ACTION_START_LIVE = "com.echo.app.WIDGET_START_LIVE"
        const val ACTION_STOP_LIVE = "com.echo.app.WIDGET_STOP_LIVE"
    }
}
