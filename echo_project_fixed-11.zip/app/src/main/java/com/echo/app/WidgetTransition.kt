package com.echo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.RemoteViews

/**
 * Multi-frame RemoteViews transitions between widget modes.
 * Modes: idle → listening → live → idle
 */
object WidgetTransition {
    private val handler = Handler(Looper.getMainLooper())
    private var running: Runnable? = null

    private val WAVE = intArrayOf(
        R.drawable.widget_wave_0,
        R.drawable.widget_wave_1,
        R.drawable.widget_wave_2,
        R.drawable.widget_wave_3
    )

    enum class Mode { IDLE, LISTENING, LIVE }

    fun currentMode(ctx: Context): Mode = when {
        EchoState.isLive(ctx) -> Mode.LIVE
        EchoState.isListening(ctx) -> Mode.LISTENING
        else -> Mode.IDLE
    }

    fun previousMode(ctx: Context): Mode {
        val v = EchoState.prefs(ctx).getString("widget_prev_mode", Mode.IDLE.name) ?: Mode.IDLE.name
        return try { Mode.valueOf(v) } catch (_: Exception) { Mode.IDLE }
    }

    fun rememberMode(ctx: Context, mode: Mode) {
        EchoState.prefs(ctx).edit().putString("widget_prev_mode", mode.name).apply()
    }

    /**
     * Call after state change. Animates 3×1 (and refreshes 1×1) then settles on final UI.
     */
    fun animateModeChange(ctx: Context) {
        val app = ctx.applicationContext
        val from = previousMode(app)
        val to = currentMode(app)
        rememberMode(app, to)

        running?.let { handler.removeCallbacks(it) }
        running = null

        if (from == to) {
            WidgetUpdater.refreshAll(app)
            return
        }

        val mgr = AppWidgetManager.getInstance(app)
        val ids3 = mgr.getAppWidgetIds(ComponentName(app, EchoWidget3x1::class.java))
        val ids1 = mgr.getAppWidgetIds(ComponentName(app, EchoWidget1x1::class.java))

        val steps = buildSteps(from, to)
        var i = 0
        val tick = object : Runnable {
            override fun run() {
                if (i >= steps.size) {
                    WidgetUpdater.refreshAll(app)
                    running = null
                    return
                }
                val step = steps[i++]
                if (ids3.isNotEmpty()) {
                    for (id in ids3) mgr.updateAppWidget(id, step.build3(app))
                }
                if (ids1.isNotEmpty()) {
                    for (id in ids1) mgr.updateAppWidget(id, step.build1(app))
                }
                handler.postDelayed(this, step.delayMs)
            }
        }
        running = tick
        handler.post(tick)
    }

    /** Soft pulse while listening (called from tick). */
    fun pulseListening(ctx: Context, phase: Int) {
        if (currentMode(ctx) != Mode.LISTENING) return
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        val ids3 = mgr.getAppWidgetIds(ComponentName(app, EchoWidget3x1::class.java))
        val ids1 = mgr.getAppWidgetIds(ComponentName(app, EchoWidget1x1::class.java))
        val alpha = if (phase % 2 == 0) 1f else 0.72f
        val scaleHint = if (phase % 2 == 0) 1f else 0.92f
        for (id in ids3) {
            val rv = baseNormal(app, listening = true, timer = EchoState.formatTimer(app), btnAlpha = alpha)
            mgr.updateAppWidget(id, rv)
        }
        for (id in ids1) {
            val rv = RemoteViews(app.packageName, R.layout.widget_1x1)
            rv.setImageViewResource(R.id.widget_btn, R.drawable.ic_fab_listening)
            setAlpha(rv, R.id.widget_btn, alpha)
            rv.setOnClickPendingIntent(R.id.widget_btn, togglePi(app))
            rv.setOnClickPendingIntent(R.id.widget_root, togglePi(app))
            mgr.updateAppWidget(id, rv)
        }
    }

    private data class Step(
        val delayMs: Long,
        val build3: (Context) -> RemoteViews,
        val build1: (Context) -> RemoteViews
    )

    private fun buildSteps(from: Mode, to: Mode): List<Step> {
        return when {
            // idle → listening: crossfade ring, then reveal timer
            from == Mode.IDLE && to == Mode.LISTENING -> listOf(
                Step(70, { c -> baseNormal(c, false, null, 1f) }, { c -> btn1(c, false, 1f) }),
                Step(70, { c -> baseNormal(c, false, null, 0.35f) }, { c -> btn1(c, false, 0.35f) }),
                Step(70, { c -> baseNormal(c, true, null, 0.35f) }, { c -> btn1(c, true, 0.35f) }),
                Step(90, { c -> baseNormal(c, true, "00:00", 0.7f) }, { c -> btn1(c, true, 0.7f) }),
                Step(100, { c -> baseNormal(c, true, EchoState.formatTimer(c), 1f) }, { c -> btn1(c, true, 1f) })
            )
            // listening → idle
            from == Mode.LISTENING && to == Mode.IDLE -> listOf(
                Step(60, { c -> baseNormal(c, true, EchoState.formatTimer(c), 1f) }, { c -> btn1(c, true, 1f) }),
                Step(70, { c -> baseNormal(c, true, null, 0.4f) }, { c -> btn1(c, true, 0.4f) }),
                Step(70, { c -> baseNormal(c, false, null, 0.4f) }, { c -> btn1(c, false, 0.4f) }),
                Step(90, { c -> baseNormal(c, false, null, 1f) }, { c -> btn1(c, false, 1f) })
            )
            // → live: morph to white + wave
            to == Mode.LIVE -> listOf(
                Step(60, { c -> baseNormal(c, from == Mode.LISTENING, if (from == Mode.LISTENING) EchoState.formatTimer(c) else null, 0.5f) },
                    { c -> btn1(c, true, 0.5f) }),
                Step(80, { c -> live(c, "Подключаюсь…", 0, 0.4f) }, { c -> btn1(c, true, 0.3f) }),
                Step(80, { c -> live(c, "Подключаюсь…", 1, 0.7f) }, { c -> btn1(c, true, 0.5f) }),
                Step(100, { c -> live(c, EchoState.liveStatus(c), 2, 1f) }, { c -> btn1(c, true, 1f) })
            )
            // live → idle/listening
            from == Mode.LIVE -> listOf(
                Step(70, { c -> live(c, EchoState.liveStatus(c), EchoState.waveFrame(c), 0.7f) },
                    { c -> btn1(c, to == Mode.LISTENING, 0.5f) }),
                Step(80, { c -> live(c, "", EchoState.waveFrame(c), 0.25f) },
                    { c -> btn1(c, to == Mode.LISTENING, 0.35f) }),
                Step(90, { c ->
                    if (to == Mode.LISTENING) baseNormal(c, true, EchoState.formatTimer(c), 0.6f)
                    else baseNormal(c, false, null, 0.6f)
                }, { c -> btn1(c, to == Mode.LISTENING, 0.6f) }),
                Step(100, { c ->
                    if (to == Mode.LISTENING) baseNormal(c, true, EchoState.formatTimer(c), 1f)
                    else baseNormal(c, false, null, 1f)
                }, { c -> btn1(c, to == Mode.LISTENING, 1f) })
            )
            else -> emptyList()
        }
    }

    private fun setAlpha(rv: RemoteViews, id: Int, a: Float) {
        try {
            rv.setFloat(id, "setAlpha", a.coerceIn(0f, 1f))
        } catch (_: Exception) { }
    }

    private fun togglePi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 32,
        Intent(ctx, WidgetActionReceiver::class.java).setAction(WidgetActionReceiver.ACTION_TOGGLE_LISTEN),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun livePi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 33,
        Intent(ctx, WidgetActionReceiver::class.java).setAction(WidgetActionReceiver.ACTION_START_LIVE),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun stopPi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 31,
        Intent(ctx, WidgetActionReceiver::class.java).setAction(WidgetActionReceiver.ACTION_STOP_LIVE),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun btn1(ctx: Context, listening: Boolean, alpha: Float): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_1x1)
        rv.setImageViewResource(
            R.id.widget_btn,
            if (listening) R.drawable.ic_fab_listening else R.drawable.ic_fab_idle
        )
        setAlpha(rv, R.id.widget_btn, alpha)
        val pi = togglePi(ctx)
        rv.setOnClickPendingIntent(R.id.widget_btn, pi)
        rv.setOnClickPendingIntent(R.id.widget_root, pi)
        return rv
    }

    private fun baseNormal(
        ctx: Context,
        listening: Boolean,
        timer: String?,
        btnAlpha: Float
    ): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_3x1)
        rv.setViewVisibility(R.id.mode_normal, View.VISIBLE)
        rv.setViewVisibility(R.id.mode_live, View.GONE)
        rv.setImageViewResource(
            R.id.widget_btn,
            if (listening) R.drawable.ic_fab_listening else R.drawable.ic_fab_idle
        )
        setAlpha(rv, R.id.widget_btn, btnAlpha)
        if (timer != null) {
            rv.setViewVisibility(R.id.widget_timer, View.VISIBLE)
            rv.setViewVisibility(R.id.widget_hint, View.GONE)
            rv.setTextViewText(R.id.widget_timer, timer)
            setAlpha(rv, R.id.widget_timer, btnAlpha)
        } else {
            rv.setViewVisibility(R.id.widget_timer, View.GONE)
            rv.setViewVisibility(R.id.widget_hint, View.VISIBLE)
            setAlpha(rv, R.id.widget_hint, btnAlpha)
        }
        rv.setOnClickPendingIntent(R.id.widget_btn, togglePi(ctx))
        rv.setOnClickPendingIntent(R.id.widget_hint, livePi(ctx))
        rv.setOnClickPendingIntent(R.id.widget_timer, togglePi(ctx))
        return rv
    }

    private fun live(ctx: Context, status: String, frame: Int, alpha: Float): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_3x1)
        rv.setViewVisibility(R.id.mode_normal, View.GONE)
        rv.setViewVisibility(R.id.mode_live, View.VISIBLE)
        rv.setTextViewText(R.id.widget_status, status)
        rv.setImageViewResource(R.id.widget_wave, WAVE[frame % WAVE.size])
        setAlpha(rv, R.id.mode_live, alpha)
        setAlpha(rv, R.id.widget_wave, alpha)
        setAlpha(rv, R.id.widget_status, alpha)
        val stop = stopPi(ctx)
        rv.setOnClickPendingIntent(R.id.mode_live, stop)
        rv.setOnClickPendingIntent(R.id.widget_wave, stop)
        rv.setOnClickPendingIntent(R.id.widget_status, stop)
        return rv
    }
}
