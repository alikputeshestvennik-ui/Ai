package com.echo.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock

object WidgetUpdater {
    const val ACTION_TICK = "com.echo.app.WIDGET_TICK"

    fun refreshAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids1 = mgr.getAppWidgetIds(ComponentName(ctx, EchoWidget1x1::class.java))
        if (ids1.isNotEmpty()) EchoWidget1x1.updateAll(ctx, mgr, ids1)
        val ids3 = mgr.getAppWidgetIds(ComponentName(ctx, EchoWidget3x1::class.java))
        if (ids3.isNotEmpty()) EchoWidget3x1.updateAll(ctx, mgr, ids3)
    }

    /** Schedule 1s ticks while listening or live for timer / wave animation. */
    fun scheduleTick(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = tickPi(ctx)
        am.cancel(pi)
        if (!EchoState.isListening(ctx) && !EchoState.isLive(ctx)) return
        try {
            am.setExactAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 1000L,
                pi
            )
        } catch (_: SecurityException) {
            am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 1000L, pi)
        }
    }

    fun cancelTick(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(tickPi(ctx))
    }

    private fun tickPi(ctx: Context): PendingIntent {
        val i = Intent(ctx, WidgetActionReceiver::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(
            ctx, 90, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
