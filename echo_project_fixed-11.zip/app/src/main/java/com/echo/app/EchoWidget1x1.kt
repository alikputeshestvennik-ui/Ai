package com.echo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class EchoWidget1x1 : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(context, mgr, ids)
    }

    override fun onEnabled(context: Context) {
        WidgetUpdater.refreshAll(context)
    }

    companion object {
        fun updateAll(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_1x1)
                val listening = EchoState.isListening(ctx) || EchoState.isLive(ctx)
                rv.setImageViewResource(
                    R.id.widget_btn,
                    if (listening) R.drawable.ic_fab_listening else R.drawable.ic_fab_idle
                )
                val pi = PendingIntent.getBroadcast(
                    ctx, 11,
                    Intent(ctx, WidgetActionReceiver::class.java).setAction(WidgetActionReceiver.ACTION_TOGGLE_LISTEN),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                rv.setOnClickPendingIntent(R.id.widget_btn, pi)
                rv.setOnClickPendingIntent(R.id.widget_root, pi)
                mgr.updateAppWidget(id, rv)
            }
        }
    }
}
