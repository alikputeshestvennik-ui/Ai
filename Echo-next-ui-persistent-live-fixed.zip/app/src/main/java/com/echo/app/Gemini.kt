package com.echo.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Gemini {

    private const val TAG = "EchoGemini"
    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var connected = false
    @Volatile private var setupReady = false
    private var setupLatch: CountDownLatch? = null
    private val sendLock = Any()

    // One persistent Live session is shared by all speech cards while listening.
    suspend fun startLive(onFinalTranscript: (String) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            if (connected && setupReady) return@withContext true

            val key = BuildConfig.GEMINI_API_KEY.trim()
            if (key.isBlank()) {
                Log.e(TAG, "GEMINI_API_KEY is empty")
                return@withContext false
            }

            val latch = CountDownLatch(1)
            setupLatch = latch

            val ws = client.newWebSocket(
                Request.Builder().url("$WS?key=$key").build(),
                object : WebSocketListener() {

                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        socket = webSocket
                        connected = true
                        setupReady = false

                        val setup = JSONObject()
                            .put(
                                "setup",
                                JSONObject()
                                    .put("model", "models/gemini-3.5-transcribe-live")
                                    .put(
                                        "generationConfig",
                                        JSONObject().put(
                                            "responseModalities",
                                            JSONArray().put("TEXT")
                                        )
                                    )
                                    .put(
                                        "inputAudioTranscription",
                                        JSONObject()
                                            .put("languageCodes", JSONArray())
                                            .put("mode", "SMART")
                                    )
                            )

                        Log.d(TAG, "Live WebSocket opened; sending setup")
                        webSocket.send(setup.toString())
                    }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        try {
                            val json = JSONObject(text)

                            if (json.has("setupComplete")) {
                                setupReady = true
                                setupLatch?.countDown()
                                Log.d(TAG, "Live setup complete")
                            }

                            val server = json.optJSONObject("serverContent") ?: return

                            server.optJSONObject("interimInputTranscription")
                                ?.optString("text")
                                ?.takeIf { it.isNotBlank() }
                                ?.let {
                                    Log.d(TAG, "INTERIM: $it")
                                }

                            server.optJSONObject("inputTranscription")
                                ?.optString("text")
                                ?.takeIf { it.isNotBlank() }
                                ?.let {
                                    Log.d(TAG, "FINAL: $it")
                                    onFinalTranscript(it.trim())
                                }

                        } catch (e: Exception) {
                            Log.e(TAG, "Cannot parse Live message: $text", e)
                        }
                    }

                    override fun onFailure(
                        webSocket: WebSocket,
                        t: Throwable,
                        response: Response?
                    ) {
                        Log.e(TAG, "Live WebSocket failure HTTP=${response?.code}", t)
                        connected = false
                        setupReady = false
                        setupLatch?.countDown()
                    }

                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                        Log.d(TAG, "Live WebSocket closed code=$code reason=$reason")
                        connected = false
                        setupReady = false
                    }
                }
            )

            socket = ws

            if (!latch.await(10, TimeUnit.SECONDS)) {
                Log.e(TAG, "Live setup timeout")
                ws.cancel()
                socket = null
                connected = false
                setupReady = false
                return@withContext false
            }

            setupReady
        }

    // Sends PCM continuously through the already-open Live session.
    // The caller supplies approximately 100 ms batches (or smaller final batches).
    fun sendAudio(chunk: ByteArray): Boolean {
        synchronized(sendLock) {
            val ws = socket ?: return false
            if (!connected || !setupReady) return false

            val message = JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put(
                        "audio",
                        JSONObject()
                            .put("mimeType", "audio/pcm;rate=16000")
                            .put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
                    )
                )

            return ws.send(message.toString())
        }
    }

    // Ends only the current speech turn. The WebSocket stays alive for the next card.
    fun endSpeech(): Boolean {
        synchronized(sendLock) {
            val ws = socket ?: return false
            if (!connected || !setupReady) return false

            Log.d(TAG, "Ending current speech turn")
            return ws.send(
                JSONObject()
                    .put(
                        "realtimeInput",
                        JSONObject().put("audioStreamEnd", true)
                    )
                    .toString()
            )
        }
    }

    fun stopLive() {
        synchronized(sendLock) {
            socket?.close(1000, "listening stopped")
            socket = null
            connected = false
            setupReady = false
            setupLatch = null
        }
    }

    suspend fun extract(prompt: String): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank()) return@withContext ""

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json")
            )

        val request = Request.Builder()
            .url(
                "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "gemini-3.5-flash-lite:generateContent?key=$key"
            )
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext ""

            val responseBody = response.body?.string() ?: return@withContext ""
            val json = JSONObject(responseBody)

            json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}
