package com.echo.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var cards: LinearLayout
    private var selectedTab = 0

    private val bg = Color.BLACK
    private val panel = Color.rgb(18, 19, 23)
    private val primaryText = Color.rgb(245, 247, 250)
    private val muted = Color.rgb(145, 149, 160)
    private val accent = Color.rgb(92, 150, 255)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }

        buildUi()
        refreshLoop()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun label(value: String, size: Float, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            includeFontPadding = false
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(10))
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val brand = label("Эхо", 34f, primaryText).apply {
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        header.addView(brand)

        status = label("Готово", 15f, muted)
        header.addView(status, LinearLayout.LayoutParams(-1, dp(28)))

        val search = EditText(this).apply {
            hint = "Искать в записях за всё время..."
            setHintTextColor(Color.rgb(95, 99, 110))
            setTextColor(primaryText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(panel, 16)
        }
        header.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(10)
        })

        root.addView(header)

        val content = FrameLayout(this)
        cards = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, dp(90))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(cards)
        }
        content.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val fab = TextView(this).apply {
            text = "●"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Color.WHITE)
            background = rounded(accent, 50)
            elevation = dp(8).toFloat()
            setOnClickListener { toggle() }
            setOnLongClickListener {
                showLive()
                true
            }
        }
        val fabParams = FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabParams.bottomMargin = dp(66)
        content.addView(fab, fabParams)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            background = ColorDrawableCompat(panel)
        }

        val feed = navItem("Лента", 0)
        val memory = navItem("Память", 1)
        val settings = navItem("Настройки", 2)
        nav.addView(feed, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(memory, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(settings, LinearLayout.LayoutParams(0, dp(52), 1f))

        root.addView(nav)
        setContentView(root)
        selectTab(0)
    }

    private fun navItem(title: String, tab: Int): TextView =
        label(title, 13f, muted).apply {
            gravity = Gravity.CENTER
            setOnClickListener { selectTab(tab) }
        }

    private fun selectTab(tab: Int) {
        selectedTab = tab
        when (tab) {
            0 -> {
                status.text = if (getPreferences(0).getBoolean("running", false))
                    "Эхо слушает..." else "Готово"
                loadCards()
            }
            1 -> {
                status.text = "Багаж фактов"
                cards.removeAllViews()
                addEmpty("Здесь появятся устойчивые факты, которые Эхо запомнило.")
            }
            2 -> {
                status.text = "Настройки"
                cards.removeAllViews()
                addSetting("Аудио", "Хранить оригинальные записи 72 часа")
                addSetting("Поиск", "Контекст последней недели")
                addSetting("Язык", "Автоматический")
            }
        }
    }

    private fun addEmpty(message: String) {
        cards.addView(label(message, 16f, muted).apply {
            setPadding(dp(4), dp(30), dp(4), dp(30))
        })
    }

    private fun addSetting(title: String, subtitle: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(panel, 18)
        }
        row.addView(label(title, 16f, primaryText))
        row.addView(label(subtitle, 13f, muted).apply {
            setPadding(0, dp(5), 0, 0)
        })
        cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })
    }

    private fun loadCards() {
        lifecycleScope.launch {
            val list = EchoDb.get(this@MainActivity).cards().all()
            cards.removeAllViews()
            if (list.isEmpty()) {
                addEmpty("Пока нет записей.\nНажми ● и начни говорить.")
                return@launch
            }
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            list.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(panel, 18)
                }
                card.addView(label(fmt.format(Date(c.createdAt)), 12f, muted))
                card.addView(label(c.text, 16f, primaryText).apply {
                    setPadding(0, dp(7), 0, 0)
                })
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
            }
        }
    }

    private fun refreshLoop() {
        lifecycleScope.launch {
            while (!isFinishing) {
                if (selectedTab == 0) loadCards()
                delay(2500)
            }
        }
    }

    private fun toggle() {
        val running = getPreferences(0).getBoolean("running", false)
        val intent = Intent(this, ListeningService::class.java).apply {
            action = if (running) "stop" else "start"
        }
        if (running) {
            stopService(intent)
        } else {
            startForegroundService(intent)
        }
        getPreferences(0).edit().putBoolean("running", !running).apply()
        status.text = if (running) "Готово" else "Эхо слушает..."
    }

    private fun showLive() {
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(30), dp(28), dp(30))
            setBackgroundColor(Color.argb(245, 5, 6, 8))
        }
        val title = label("Эхо слушает...", 24f, primaryText).apply {
            gravity = Gravity.CENTER
        }
        val pulse = label("◉", 92f, accent).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(40), 0, dp(20))
        }
        val subtitle = label("Live 3.8\nподключение через Gemini Live API", 15f, muted).apply {
            gravity = Gravity.CENTER
        }
        val close = Button(this).apply {
            text = "ЗАВЕРШИТЬ"
            setOnClickListener { (overlay.parent as? ViewGroup)?.removeView(overlay) }
        }
        overlay.addView(title)
        overlay.addView(pulse)
        overlay.addView(subtitle)
        overlay.addView(close, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(28)
        })

        addContentView(overlay, ViewGroup.LayoutParams(-1, -1))
    }

    private object ColorDrawableCompat {
        operator fun invoke(color: Int) = android.graphics.drawable.ColorDrawable(color)
    }
}
