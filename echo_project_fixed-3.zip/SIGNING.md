# Echo signing

The workflow uses exactly two GitHub Actions secrets:

- `ECHO` — signing password.
- `GEMINI` — Gemini API key.

Important: a password alone does **not** reproduce the same Android signing key. The current workflow generates a new keystore when it builds, so successive APKs are not guaranteed to install as updates over an older APK.

For a production/update-safe release, the same keystore must be preserved between builds (for example by storing the keystore itself inside one GitHub secret). Do not change the signing key after users install the app.
