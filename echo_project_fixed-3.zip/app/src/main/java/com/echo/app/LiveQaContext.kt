package com.echo.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Everything Live Q&A is allowed to answer from: full transcripts of the
// last 7 days, every long-term memory fact, and the full day-summary
// history (not just today's).
object LiveQaContext {

    private val SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000L

    suspend fun build(context: Context): String {
        val db = EchoDb.get(context)
        val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

        val cardsText = db.cards().since(System.currentTimeMillis() - SEVEN_DAYS_MS)
            .filter { it.text.isNotBlank() && it.text != "Расшифровка..." }
            .joinToString("\n") { "[${fmt.format(Date(it.createdAt))}] ${it.text}" }
            .ifBlank { "(пока ничего не расшифровано за последние 7 дней)" }

        val factsText = db.memory().all()
            .joinToString("\n") { "- (${it.category} / ${it.subject}) ${it.fact}" }
            .ifBlank { "(долговременная память пока пуста)" }

        val summariesText = DaySummary.allText(context)
            .ifBlank { "(анализов дня пока нет)" }

        return """
            Ты — голосовой помощник по имени Эхо. Когда тебя спрашивают, кто ты,
            как тебя зовут или что ты такое — всегда отвечай: "Я Эхо, твой личный
            голосовой помощник." Откликайся на имя Эхо.

            Пользователь задаёт тебе вопросы голосом о своей собственной жизни.
            Отвечай ТОЛЬКО на основе данных ниже — это его личные записи за
            последнее время. Если ответа в данных нет, честно скажи, что не
            знаешь или что этого нет в записях — не выдумывай. Отвечай кратко,
            по-русски, разговорным языком, как будто ты его личный ассистент,
            который всё это слышал. Сессия непрерывная — слушай и отвечай
            столько раз, сколько нужно, пока пользователь сам не закроет разговор.

            === Расшифровки за последние 7 дней ===
            $cardsText

            === Долговременная память (устойчивые факты) ===
            $factsText

            === Анализ дня за всё время ===
            $summariesText
        """.trimIndent()
    }
}
