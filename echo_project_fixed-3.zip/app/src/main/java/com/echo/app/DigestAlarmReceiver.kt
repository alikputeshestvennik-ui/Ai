package com.echo.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

// Fires once a day at 22:00 so the day gets locked (DaySummary.runIfDue sees
// isPastLockHour() == true and sets isFinal = true) even if the user never
// opens the app that evening. Reschedules itself for the next day right
// after running -- also (re)scheduled from MainActivity.onCreate() so it
// survives a reboot as long as the app is opened at least once a day.
class DigestAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                DaySummary.runIfDue(appContext)
                Log.d("EchoDigestAlarm", "22:00 day finalization ran")
            } catch (e: Exception) {
                Log.e("EchoDigestAlarm", "22:00 finalize failed", e)
            } finally {
                schedule(appContext)
                pending.finish()
            }
        }
    }

    companion object {
        private const val REQUEST_CODE = 4200
        private const val LOCK_HOUR = 22

        fun schedule(context: Context) {
            val am = context.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                Intent(context, DigestAlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // An inexact window is fine for a once-a-day housekeeping task and,
            // unlike setExactAndAllowWhileIdle, needs no special "exact alarm"
            // permission on newer Android versions.
            am.setWindow(AlarmManager.RTC_WAKEUP, nextTrigger(), 15 * 60 * 1000L, pi)
        }

        private fun nextTrigger(): Long {
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, LOCK_HOUR)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            return cal.timeInMillis
        }
    }
}
