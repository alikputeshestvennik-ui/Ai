package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.MediaPlayer;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class HistoryActivity extends Activity {
    private LinearLayout listContainer;
    private MediaPlayer player;
    private String currentlyPlayingId = null;
    private String selectedCategory = "Все";

    private final BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            drawList();
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, new IntentFilter(RecordingService.ENTRIES), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(updateReceiver, new IntentFilter(RecordingService.ENTRIES));
        }
        drawList();
    }

    private void drawList() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        listContainer.setPadding(padH, padV, padH, padV);

        ArrayList<Entry> allEntries = new EntryStore(this).all();

        // Studio Header
        listContainer.addView(UI.createHeader(this, "История событий", "Всего фрагментов в архиве: " + allEntries.size(), true));

        // Export toolbar
        LinearLayout exportBar = new LinearLayout(this);
        exportBar.setOrientation(LinearLayout.HORIZONTAL);
        exportBar.setGravity(Gravity.CENTER_VERTICAL);
        exportBar.setPadding(0, 0, 0, UI.dp(this, 14));

        Button exportBtn = UI.secondaryButton(this, "📥 Экспорт в Markdown (.md)");
        exportBtn.setOnClickListener(v -> {
            try {
                File exported = ExportManager.exportToMarkdown(this);
                new AlertDialog.Builder(this)
                        .setTitle("Экспорт завершён")
                        .setMessage("Дневник сохранён в папку Downloads:\n" + exported.getName())
                        .setPositiveButton("Понятно", null)
                        .show();
            } catch (Exception ex) {
                Toast.makeText(this, "Ошибка экспорта: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        exportBar.addView(exportBtn);
        listContainer.addView(exportBar);

        // Filter chips: Все, Задачи, Встречи, Идеи, Часы, Заметки
        HorizontalScrollView chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setPadding(0, 0, 0, UI.dp(this, 14));

        String[] categories = new String[]{"Все", "Задачи", "Встречи", "Идеи", "Часы", "Заметки"};
        for (String cat : categories) {
            boolean active = cat.equals(selectedCategory);
            Button chip = new Button(this);
            chip.setText(cat);
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            chip.setAllCaps(false);
            chip.setTypeface(Typeface.create("sans-serif-medium", active ? Typeface.BOLD : Typeface.NORMAL));
            chip.setTextColor(active ? Color.WHITE : UI.COLOR_TEXT_MUTED);

            if (active) {
                chip.setBackground(UI.buttonRipple(UI.gradient(UI.COLOR_ORANGE, UI.COLOR_ORANGE_LIGHT, 10, this), 0x44FFFFFF));
            } else {
                chip.setBackground(UI.buttonRipple(UI.shape(UI.COLOR_SURFACE, UI.COLOR_BORDER, 10, this), 0x22F47721));
            }

            int chPadH = UI.dp(this, 14);
            int chPadV = UI.dp(this, 6);
            chip.setPadding(chPadH, chPadV, chPadH, chPadV);

            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
            clp.rightMargin = UI.dp(this, 8);
            chip.setOnClickListener(v -> {
                selectedCategory = cat;
                drawList();
            });
            chipRow.addView(chip, clp);
        }
        chipScroll.addView(chipRow);
        listContainer.addView(chipScroll);

        // Filter entries
        ArrayList<Entry> filtered = new ArrayList<>();
        for (Entry e : allEntries) {
            String cleaned = AutoTranscriber.cleanHallucinations(e.transcript);
            if (e.transcript != null && !e.transcript.isEmpty() && cleaned.length() < 2) {
                continue;
            }
            if ("Все".equals(selectedCategory) || selectedCategory.equalsIgnoreCase(e.category)) {
                filtered.add(e);
            }
        }

        if (filtered.isEmpty()) {
            LinearLayout emptyCard = UI.createCard(this);
            emptyCard.setGravity(Gravity.CENTER);
            int emptyPad = UI.dp(this, 36);
            emptyCard.setPadding(emptyPad, emptyPad, emptyPad, emptyPad);

            TextView emptyTitle = new TextView(this);
            emptyTitle.setText("В этой категории пока нет записей");
            emptyTitle.setTextColor(UI.COLOR_TEXT_TITLE);
            emptyTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            emptyTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            emptyCard.addView(emptyTitle);

            listContainer.addView(emptyCard);
        } else {
            for (Entry e : filtered) {
                renderEntryCard(e);
            }
        }

        scroll.addView(listContainer);
        setContentView(scroll);
    }

    private void renderEntryCard(Entry e) {
        LinearLayout card = e.important ? UI.createImportantCard(this) : UI.createCard(this);

        // Top metadata row
        LinearLayout metaRow = new LinearLayout(this);
        metaRow.setOrientation(LinearLayout.HORIZONTAL);
        metaRow.setGravity(Gravity.CENTER_VERTICAL);

        if (e.important) {
            TextView importantBadge = UI.badge(this, "★ ВАЖНО", UI.COLOR_ORANGE_LIGHT, 0x33F47721);
            metaRow.addView(importantBadge);
        }

        String catTag = (e.category != null && !e.category.isEmpty()) ? e.category : "Заметка";
        int catBg = "Часы".equalsIgnoreCase(catTag) ? 0x22FFA05C : 0x22F47721;
        TextView catBadge = UI.badge(this, catTag, UI.COLOR_ORANGE, catBg);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
        if (e.important) clp.leftMargin = UI.dp(this, 6);
        metaRow.addView(catBadge, clp);

        TextView timeBadge = UI.badge(this, e.created, UI.COLOR_TEXT_PRIMARY, 0xFF191C24);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.leftMargin = UI.dp(this, 6);
        metaRow.addView(timeBadge, tlp);

        TextView durBadge = UI.badge(this, e.duration + " с", UI.COLOR_TEXT_MUTED, 0xFF14171E);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-2, -2);
        dlp.leftMargin = UI.dp(this, 6);
        metaRow.addView(durBadge, dlp);

        View spacer = new View(this);
        LinearLayout.LayoutParams splp = new LinearLayout.LayoutParams(0, 1, 1.0f);
        metaRow.addView(spacer, splp);

        boolean isDone = "Готово".equals(e.status);
        boolean isTranscribing = e.status != null && e.status.contains("Расшифровка");
        int statusColor = isDone ? UI.COLOR_GREEN : (isTranscribing ? UI.COLOR_ORANGE : UI.COLOR_TEXT_MUTED);
        int statusBg = isDone ? UI.COLOR_GREEN_BG : (isTranscribing ? UI.COLOR_ORANGE_DIM : 0xFF1C2027);
        TextView statusPill = UI.badge(this, e.status, statusColor, statusBg);
        metaRow.addView(statusPill);

        card.addView(metaRow);

        // Polished Text content
        TextView body = new TextView(this);
        String clean = AutoTranscriber.cleanHallucinations(e.transcript);
        String text = clean.isEmpty()
                ? "Текст появится автоматически после обработки в Whisper..."
                : QwenEngine.polishSpokenRussian(clean);
        body.setText(text);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        body.setTextColor(clean.isEmpty() ? UI.COLOR_TEXT_MUTED : UI.COLOR_TEXT_PRIMARY);
        body.setLineSpacing(UI.dp(this, 4), 1.0f);
        body.setPadding(0, UI.dp(this, 12), 0, UI.dp(this, 14));
        card.addView(body);

        // Actions Row (Play, Copy, Retry, Delete)
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        File audioFile = (e.path != null && !e.path.isEmpty()) ? new File(e.path) : null;
        boolean hasAudio = audioFile != null && audioFile.exists() && audioFile.length() > 0;

        boolean isPlayingThis = e.id.equals(currentlyPlayingId) && player != null && player.isPlaying();
        Button playBtn = UI.secondaryButton(this, isPlayingThis ? "⏹ Стоп" : "▶ Слушать");
        if (!hasAudio) {
            playBtn.setText("Аудио очищено");
            playBtn.setEnabled(false);
            playBtn.setTextColor(UI.COLOR_TEXT_SUBTLE);
        } else {
            playBtn.setOnClickListener(v -> togglePlay(e));
        }
        actions.addView(playBtn);

        Button copyBtn = UI.secondaryButton(this, "Копировать");
        LinearLayout.LayoutParams showLp = new LinearLayout.LayoutParams(-2, -2);
        showLp.leftMargin = UI.dp(this, 8);
        copyBtn.setOnClickListener(v -> {
            String toCopy = clean.isEmpty() ? e.status : clean;
            UI.copyToClipboard(this, "Запись", toCopy);
        });
        actions.addView(copyBtn, showLp);

        if (e.status != null && e.status.startsWith("Ошибка")) {
            Button retryBtn = UI.secondaryButton(this, "Повторить");
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-2, -2);
            rlp.leftMargin = UI.dp(this, 8);
            retryBtn.setOnClickListener(v -> {
                AutoTranscriber.enqueue(this, e);
                Toast.makeText(this, "Повторный запуск Whisper...", Toast.LENGTH_SHORT).show();
                drawList();
            });
            actions.addView(retryBtn, rlp);
        }

        Button delBtn = UI.secondaryButton(this, "✕");
        delBtn.setTextColor(UI.COLOR_RED);
        LinearLayout.LayoutParams dlp2 = new LinearLayout.LayoutParams(-2, -2);
        dlp2.leftMargin = UI.dp(this, 8);
        delBtn.setOnClickListener(v -> confirmDelete(e));
        actions.addView(delBtn, dlp2);

        card.addView(actions);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = UI.dp(this, 12);
        listContainer.addView(card, cardLp);
    }

    private void togglePlay(Entry e) {
        try {
            if (player != null) {
                player.stop();
                player.release();
                player = null;
            }

            if (e.id.equals(currentlyPlayingId)) {
                currentlyPlayingId = null;
                drawList();
                return;
            }

            player = new MediaPlayer();
            player.setDataSource(e.path);
            player.prepare();
            player.setOnCompletionListener(mp -> {
                currentlyPlayingId = null;
                drawList();
            });
            player.start();
            currentlyPlayingId = e.id;
            Toast.makeText(this, "Воспроизведение: " + e.created, Toast.LENGTH_SHORT).show();
            drawList();
        } catch (Exception x) {
            currentlyPlayingId = null;
            Toast.makeText(this, "Не удалось воспроизвести: " + x.getMessage(), Toast.LENGTH_SHORT).show();
            drawList();
        }
    }

    private void confirmDelete(Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Удалить запись?")
                .setMessage("Фрагмент за " + e.created + " будет удалён.")
                .setPositiveButton("Удалить", (dialog, which) -> {
                    if (e.id.equals(currentlyPlayingId) && player != null) {
                        try { player.stop(); player.release(); } catch (Exception ignored) {}
                        player = null;
                        currentlyPlayingId = null;
                    }
                    if (e.path != null) {
                        try { new File(e.path).delete(); } catch (Exception ignored) {}
                    }
                    new EntryStore(this).delete(e.id);
                    drawList();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        try {
            unregisterReceiver(updateReceiver);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
