package com.blackbox.offline;

import android.content.Intent;
import android.os.Build;
import com.google.android.gms.wearable.ChannelClient;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/**
 * Service on the smartphone that listens for Galaxy Watch events:
 * - Remote record toggle commands
 * - Audio streamed/transferred directly from the Galaxy Watch microphone
 * - Enqueues watch audio for local Whisper + Qwen processing
 * - Sends status and transcription updates back to the watch
 */
public class PhoneWearableListenerService extends WearableListenerService {
    public static final String PATH_TOGGLE = "/blackbox/record_toggle";
    public static final String PATH_QUERY_STATE = "/blackbox/query_state";
    public static final String PATH_PHONE_STATUS = "/blackbox/phone_status";
    public static final String PATH_AUDIO_STREAM = "/blackbox/audio_stream";
    public static final String PATH_AUDIO_DATA = "/blackbox/audio_data";
    public static final String PATH_RESULT_STATUS = "/blackbox/result_status";

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {
        String path = messageEvent.getPath();
        String sourceNodeId = messageEvent.getSourceNodeId();

        if (PATH_TOGGLE.equals(path)) {
            boolean active = RecordingService.isRecordingActive;
            Intent intent = new Intent(this, RecordingService.class);
            if (active) {
                intent.setAction(RecordingService.STOP);
                startService(intent);
                replyPhoneStatus(sourceNodeId, false);
            } else {
                intent.setAction(RecordingService.START);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(intent);
                } else {
                    startService(intent);
                }
                replyPhoneStatus(sourceNodeId, true);
            }
        } else if (PATH_QUERY_STATE.equals(path)) {
            replyPhoneStatus(sourceNodeId, RecordingService.isRecordingActive);
        } else if (PATH_AUDIO_DATA.equals(path)) {
            // Direct audio payload transfer
            byte[] data = messageEvent.getData();
            if (data != null && data.length > 100) {
                saveAndProcessWatchAudio(data, sourceNodeId);
            }
        }
    }

    @Override
    public void onChannelOpened(ChannelClient.Channel channel) {
        if (PATH_AUDIO_STREAM.equals(channel.getPath())) {
            String nodeId = channel.getNodeId();
            Wearable.getChannelClient(this).getInputStream(channel).addOnSuccessListener(is -> {
                new Thread(() -> {
                    try {
                        File audioDir = new File(getExternalFilesDir(null), "audio");
                        audioDir.mkdirs();
                        String id = UUID.randomUUID().toString();
                        File dest = new File(audioDir, id + ".wav");

                        try (FileOutputStream fos = new FileOutputStream(dest)) {
                            byte[] buffer = new byte[8192];
                            int read;
                            while ((read = is.read(buffer)) != -1) {
                                fos.write(buffer, 0, read);
                            }
                            fos.flush();
                        }

                        if (dest.exists() && dest.length() > 500) {
                            processWatchAudioFile(dest, id, nodeId);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }).start();
            });
        }
    }

    private void saveAndProcessWatchAudio(byte[] data, String nodeId) {
        new Thread(() -> {
            try {
                File audioDir = new File(getExternalFilesDir(null), "audio");
                audioDir.mkdirs();
                String id = UUID.randomUUID().toString();
                File dest = new File(audioDir, id + ".wav");

                try (FileOutputStream fos = new FileOutputStream(dest)) {
                    fos.write(data);
                    fos.flush();
                }

                processWatchAudioFile(dest, id, nodeId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void processWatchAudioFile(File file, String id, String nodeId) {
        long durationSec = Math.max(1, (file.length() - 44) / (16000 * 2));
        String timeStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());

        Entry entry = new Entry(
                id,
                file.getAbsolutePath(),
                timeStr,
                durationSec,
                "",
                "⌚ Запись с Galaxy Watch",
                "Часы"
        );

        new EntryStore(this).add(entry);
        AutoTranscriber.enqueue(this, entry);
        sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(getPackageName()));

        // Notify watch that audio was successfully received and queued
        if (nodeId != null && !nodeId.isEmpty()) {
            String resp = "✓ Получено (" + durationSec + "с). Whisper расшифровывает...";
            Wearable.getMessageClient(this).sendMessage(
                    nodeId,
                    PATH_RESULT_STATUS,
                    resp.getBytes(StandardCharsets.UTF_8)
            );
        }
    }

    private void replyPhoneStatus(String nodeId, boolean isActive) {
        if (nodeId == null || nodeId.isEmpty()) return;
        String status = isActive ? "RECORDING" : "IDLE";
        Wearable.getMessageClient(this).sendMessage(
                nodeId,
                PATH_PHONE_STATUS,
                status.getBytes(StandardCharsets.UTF_8)
        );
    }
}
