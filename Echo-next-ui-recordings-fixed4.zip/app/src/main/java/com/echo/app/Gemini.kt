package com.echo.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Gemini {

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    suspend fun transcribe(chunks: List<ByteArray>): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank() || chunks.isEmpty()) return@withContext ""

        val finalText = StringBuilder()
        val interimText = StringBuilder()
        val opened = CountDownLatch(1)
        val setupDone = CountDownLatch(1)
        val finished = CountDownLatch(1)

        val socket = client.newWebSocket(
            Request.Builder().url("$WS?key=$key").build(),
            object : WebSocketListener() {

                override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                    opened.countDown()

                    val setup = JSONObject()
                        .put(
                            "setup",
                            JSONObject()
                                .put("model", "models/gemini-3.5-transcribe-live")
                                .put(
                                    "generationConfig",
                                    JSONObject().put(
                                        "responseModalities",
                                        JSONArray().put("TEXT")
                                    )
                                )
                                .put(
                                    "inputAudioTranscription",
                                    JSONObject()
                                        // Empty list = automatic language detection.
                                        .put("languageCodes", JSONArray())
                                        .put("mode", "SMART")
                                )
                        )

                    if (!webSocket.send(setup.toString())) {
                        setupDone.countDown()
                        finished.countDown()
                    }
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val json = JSONObject(text)

                        if (json.has("setupComplete")) {
                            setupDone.countDown()
                        }

                        val server = json.optJSONObject("serverContent") ?: return

                        server.optJSONObject("interimInputTranscription")
                            ?.optString("text")
                            ?.takeIf { it.isNotBlank() }
                            ?.let { partial ->
                                synchronized(interimText) {
                                    interimText.setLength(0)
                                    interimText.append(partial)
                                }
                            }

                        server.optJSONObject("inputTranscription")
                            ?.optString("text")
                            ?.takeIf { it.isNotBlank() }
                            ?.let { final ->
                                synchronized(finalText) {
                                    finalText.append(final).append(' ')
                                }
                            }

                        if (server.optBoolean("turnComplete", false)) {
                            finished.countDown()
                        }
                    } catch (e: Exception) {
                        Log.e("EchoGemini", "Cannot parse Live response: $text", e)
                    }
                }

                override fun onFailure(
                    webSocket: WebSocket,
                    t: Throwable,
                    response: okhttp3.Response?
                ) {
                    Log.e(
                        "EchoGemini",
                        "Live transcription WebSocket failed HTTP=${response?.code}",
                        t
                    )
                    opened.countDown()
                    setupDone.countDown()
                    finished.countDown()
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d("EchoGemini", "Live WebSocket closed: $code $reason")
                    finished.countDown()
                }
            }
        )

        if (!opened.await(8, TimeUnit.SECONDS)) {
            socket.cancel()
            return@withContext ""
        }

        if (!setupDone.await(8, TimeUnit.SECONDS)) {
            socket.cancel()
            return@withContext ""
        }

        // Send audio in the same raw PCM format documented for Live Transcription.
        for (chunk in chunks) {
            val message = JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put(
                        "audio",
                        JSONObject()
                            .put("mimeType", "audio/pcm;rate=16000")
                            .put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
                    )
                )

            if (!socket.send(message.toString())) {
                Log.e("EchoGemini", "WebSocket refused an audio chunk")
                break
            }

            // The microphone chunks are 20 ms; keep the stream close to real time.
            Thread.sleep(20)
        }

        socket.send(
            JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put("audioStreamEnd", true)
                )
                .toString()
        )

        // Give the service time to emit the finalized inputTranscription.
        finished.await(12, TimeUnit.SECONDS)
        Thread.sleep(250)
        socket.close(1000, "turn complete")

        synchronized(finalText) {
            val result = finalText.toString().trim()
            if (result.isNotBlank()) {
                result
            } else {
                // Do not lose a speech turn if only an interim hypothesis arrived.
                synchronized(interimText) {
                    interimText.toString().trim()
                }
            }
        }
    }

    suspend fun extract(prompt: String): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank()) return@withContext ""

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json")
            )

        val request = Request.Builder()
            .url(
                "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "gemini-3.5-flash-lite:generateContent?key=$key"
            )
            .post(
                body.toString()
                    .toRequestBody("application/json".toMediaType())
            )
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e("EchoGemini", "HTTP ${response.code}: ${response.body?.string()}")
                return@withContext ""
            }

            val responseBody = response.body?.string() ?: return@withContext ""
            val json = JSONObject(responseBody)

            json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}
