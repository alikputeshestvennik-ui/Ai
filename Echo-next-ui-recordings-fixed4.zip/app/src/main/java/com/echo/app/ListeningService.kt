package com.echo.app

import android.app.*
import android.content.*
import android.media.*
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.*
import java.io.File
import kotlin.math.sqrt

class ListeningService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        startForeground(7, notification())
    }

    private fun notification(): Notification {
        val ch = NotificationChannel(
            "echo",
            "Эхо",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(ch)

        return Notification.Builder(this, "echo")
            .setContentTitle("Эхо слушает")
            .setContentText("Фоновое распознавание включено")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            running = false
            stopSelf()
        } else if (!running) {
            running = true
            listen()
        }
        return START_NOT_STICKY
    }

    private fun listen() {
        scope.launch {
            val minBuffer = AudioRecord.getMinBufferSize(
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val bufferBytes = maxOf(6400, minBuffer)
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferBytes
            )

            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                running = false
                return@launch
            }

            val ns = if (NoiseSuppressor.isAvailable()) {
                NoiseSuppressor.create(ar.audioSessionId)
            } else null

            val agc = if (AutomaticGainControl.isAvailable()) {
                AutomaticGainControl.create(ar.audioSessionId)
            } else null

            val buf = ShortArray(320)
            val ring = ArrayDeque<ByteArray>()
            val current = ArrayList<ByteArray>()

            var speech = false
            var silentChunks = 0

            try {
                ar.startRecording()

                while (running) {
                    val n = ar.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                    if (n <= 0) continue

                    val bytes = ByteArray(n * 2)
                    var sum = 0.0

                    for (k in 0 until n) {
                        val sample = buf[k].toInt()
                        bytes[k * 2] = (sample and 0xff).toByte()
                        bytes[k * 2 + 1] = (sample shr 8).toByte()

                        val normalized = sample / 32768.0
                        sum += normalized * normalized
                    }

                    ring.addLast(bytes)
                    while (ring.size > 20) ring.removeFirst()

                    val rms = sqrt(sum / n)
                    val voice = rms > 0.012

                    if (voice) {
                        if (!speech) {
                            speech = true
                            current.clear()
                            current.addAll(ring)
                        }
                        current.add(bytes)
                        silentChunks = 0
                    } else if (speech) {
                        current.add(bytes)
                        silentChunks++

                        // 800 ms of silence closes one speech stream.
                        if (silentChunks >= 40) {
                            speech = false
                            silentChunks = 0

                            val copy = current.toList()
                            current.clear()

                            scope.launch {
                                Log.d("EchoService", "Speech turn finished: ${copy.size} PCM chunks")
                                val text = Gemini.transcribe(copy)
                                Log.d("EchoService", "Gemini transcript length=${text.length}")

                                if (text.isNotBlank()) {
                                    Log.d("EchoService", "Saving transcript: $text")
                                    val audioFile = File(
                                        filesDir,
                                        "audio_${System.currentTimeMillis()}.pcm"
                                    )

                                    audioFile.outputStream().use { out ->
                                        copy.forEach { out.write(it) }
                                    }

                                    EchoDb.get(this@ListeningService)
                                        .cards()
                                        .insert(
                                            SpeechCard(
                                                createdAt = System.currentTimeMillis(),
                                                text = text,
                                                audioPath = audioFile.absolutePath
                                            )
                                        )
                                } else {
                                    Log.e("EchoService", "Gemini returned empty transcript")
                                }
                            }
                        }
                    }
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
                ns?.release()
                agc?.release()
            }
        }
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
