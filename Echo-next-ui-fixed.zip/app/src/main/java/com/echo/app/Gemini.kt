package com.echo.app

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Gemini {

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    suspend fun transcribe(chunks: List<ByteArray>): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY
        if (key.isBlank()) {
            return@withContext ""
        }

        val output = StringBuilder()

        val listener = object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    val serverContent = json.optJSONObject("serverContent") ?: return
                    val transcription = serverContent.optJSONObject("inputTranscription") ?: return
                    val value = transcription.optString("text")

                    if (value.isNotBlank()) {
                        synchronized(output) {
                            output.append(value)
                        }
                    }
                } catch (_: Exception) {
                    // Ignore malformed/non-transcription messages.
                }
            }
        }

        val socket = client.newWebSocket(
            Request.Builder()
                .url("$WS?key=$key")
                .build(),
            listener
        )

        Thread.sleep(350)

        val setup = JSONObject()
            .put(
                "setup",
                JSONObject()
                    .put("model", "models/gemini-3.5-transcribe-live")
                    .put(
                        "generationConfig",
                        JSONObject()
                            .put("responseModalities", JSONArray().put("TEXT"))
                    )
                    .put(
                        "inputAudioTranscription",
                        JSONObject().put("mode", "SMART")
                    )
            )

        socket.send(setup.toString())

        for (chunk in chunks) {
            val encoded = Base64.encodeToString(chunk, Base64.NO_WRAP)

            val message = JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put(
                        "audio",
                        JSONObject()
                            .put("mimeType", "audio/pcm;rate=16000")
                            .put("data", encoded)
                    )
                )

            socket.send(message.toString())
        }

        socket.send(
            JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put("audioStreamEnd", true)
                )
                .toString()
        )

        Thread.sleep(1200)
        socket.close(1000, "done")

        output.toString().trim()
    }

    suspend fun extract(prompt: String): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY
        if (key.isBlank()) {
            return@withContext ""
        }

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(
                            JSONObject().put("text", prompt)
                        )
                    )
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json")
            )

        val request = Request.Builder()
            .url(
                "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "gemini-3.5-flash-lite:generateContent?key=$key"
            )
            .post(
                body.toString()
                    .toRequestBody("application/json".toMediaType())
            )
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return@withContext ""
            }

            val responseBody = response.body?.string() ?: return@withContext ""
            val json = JSONObject(responseBody)

            json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }
}
