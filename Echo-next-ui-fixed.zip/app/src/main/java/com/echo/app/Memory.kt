package com.echo.app

import android.content.Context
import androidx.room.*

@Entity(tableName="speech_cards", indices=[Index(value=["createdAt"])])
data class SpeechCard(@PrimaryKey(autoGenerate=true) val id:Long=0,val createdAt:Long,val text:String,val audioPath:String?)
@Entity(tableName="long_term_memory", indices=[Index(value=["category","subject"])])
data class MemoryFact(@PrimaryKey(autoGenerate=true) val id:Long=0,val category:String,val subject:String,val fact:String,val sourceDate:String)
@Dao interface CardDao { @Insert suspend fun insert(c:SpeechCard):Long; @Query("SELECT * FROM speech_cards ORDER BY createdAt DESC") suspend fun all():List<SpeechCard>; @Query("SELECT * FROM speech_cards WHERE createdAt >= :since ORDER BY createdAt ASC") suspend fun since(since:Long):List<SpeechCard> }
@Dao interface MemoryDao { @Insert suspend fun insertAll(x:List<MemoryFact>); @Query("SELECT * FROM long_term_memory ORDER BY category,subject") suspend fun all():List<MemoryFact>; @Query("DELETE FROM long_term_memory") suspend fun clear() }
@Database(entities=[SpeechCard::class,MemoryFact::class],version=1,exportSchema=false)
abstract class EchoDb:RoomDatabase(){ abstract fun cards():CardDao; abstract fun memory():MemoryDao
 companion object { @Volatile private var I:EchoDb?=null; fun get(c:Context)=I?:synchronized(this){I?:Room.databaseBuilder(c.applicationContext,EchoDb::class.java,"echo.db").build().also{I=it}} } }
