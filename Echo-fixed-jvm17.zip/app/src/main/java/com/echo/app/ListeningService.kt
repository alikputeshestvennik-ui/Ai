package com.echo.app

import android.app.*;import android.content.*;import android.media.*;import android.os.*;import kotlinx.coroutines.*;import java.io.*;import kotlin.math.sqrt

class ListeningService:Service(){
 private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO); private var running=false
 override fun onCreate(){super.onCreate();startForeground(7,notification())}
 private fun notification():Notification{val ch=NotificationChannel("echo","Эхо",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager::class.java).createNotificationChannel(ch);return Notification.Builder(this,"echo").setContentTitle("Эхо слушает").setContentText("Фоновое распознавание включено").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()}
 override fun onStartCommand(i:Intent?,f:Int,s:Int):Int{if(i?.action=="stop")stopSelf() else if(!running){running=true;listen()};return START_STICKY}
 private fun listen(){scope.launch{val ar=AudioRecord(MediaRecorder.AudioSource.MIC,16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,6400);val ns=NoiseSuppressor.create(ar.audioSessionId);val agc=AutomaticGainControl.create(ar.audioSessionId);ar.startRecording();val buf=ShortArray(320);val ring=ArrayDeque<ByteArray>();var speech=false;var silent=0;val current=ArrayList<ByteArray>();while(running){val n=ar.read(buf,0,buf.size);if(n<=0)continue;val bytes=ByteArray(n*2);for(k in 0 until n){bytes[k*2]=(buf[k].toInt() and 255).toByte();bytes[k*2+1]=(buf[k].toInt() shr 8).toByte()};ring.addLast(bytes);if(ring.size>20)ring.removeFirst();var sum=0.0;for(x in buf)sum+=(x/32768.0)*(x/32768.0);val rms=sqrt(sum/buf.size);if(rms>0.03){if(!speech){speech=true;current.clear();current.addAll(ring)};current.add(bytes);silent=0}else if(speech){current.add(bytes);silent++;if(silent>=40){speech=false;silent=0;val copy=current.toList();scope.launch{val text=Gemini.transcribe(copy);if(text.isNotBlank()){val f=File(filesDir,"audio_${System.currentTimeMillis()}.pcm");f.writeBytes(copy.flatten().toByteArray());EchoDb.get(this@ListeningService).cards().insert(SpeechCard(createdAt=System.currentTimeMillis(),text=text,audioPath=f.absolutePath))}}}}};try{ar.stop()}catch(_:Exception){};ar.release();ns?.release();agc?.release()}}
 override fun onDestroy(){running=false;scope.cancel();super.onDestroy()};override fun onBind(i:Intent?)=null
}
