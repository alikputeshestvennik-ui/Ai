package com.echo.app

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.*
import java.util.concurrent.TimeUnit

object Gemini {
 private val client=OkHttpClient.Builder().pingInterval(20,TimeUnit.SECONDS).build()
 private const val WS="wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
 suspend fun transcribe(chunks:List<ByteArray>):String=withContext(Dispatchers.IO){
  val key=BuildConfig.GEMINI_API_KEY;if(key.isBlank()) return@withContext ""
  val out=StringBuilder(); val done=Object(); var socket:WebSocket?=null
  val listener=object:WebSocketListener(){override fun onMessage(ws:WebSocket,t:String){try{val j=JSONObject(t); val sc=j.optJSONObject("serverContent")?:return; val tr=sc.optJSONObject("inputTranscription")?:return; val x=tr.optString("text");if(x.isNotBlank()) synchronized(out){out.append(x)}}catch(_:Exception){}}}
  socket=client.newWebSocket(Request.Builder().url("$WS?key=$key").build(),listener)
  Thread.sleep(350)
  val setup=JSONObject().put("setup",JSONObject().put("model","models/gemini-3.5-transcribe-live").put("generationConfig",JSONObject().put("responseModalities",JSONArray().put("TEXT")).put("inputAudioTranscription",JSONObject().put("mode","SMART")))
  socket.send(setup.toString())
  for(c in chunks){val b=Base64.encodeToString(c,Base64.NO_WRAP);socket.send(JSONObject().put("realtimeInput",JSONObject().put("audio",JSONObject().put("mimeType","audio/pcm;rate=16000").put("data",b))).toString())}
  socket.send(JSONObject().put("realtimeInput",JSONObject().put("audioStreamEnd",true)).toString());Thread.sleep(1200);socket.close(1000,"done");out.toString().trim() }
 suspend fun extract(prompt:String):String=withContext(Dispatchers.IO){
  val key=BuildConfig.GEMINI_API_KEY;if(key.isBlank()) return@withContext ""
  val body=JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text",prompt))))).put("generationConfig",JSONObject().put("responseMimeType","application/json"))
  val req=Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$key").post(body.toString().toRequestBody("application/json".toMediaType())).build()
  client.newCall(req).execute().use{r->if(!r.isSuccessful) return@withContext ""; val j=JSONObject(r.body!!.string());j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")}
 }
}
