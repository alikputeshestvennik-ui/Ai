package com.echo.app

import android.content.Intent
import android.util.Log
import com.google.android.gms.wearable.CapabilityClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phone-side bridge for the Galaxy Watch companion.
 *
 * Paths mirror com.echo.wear.bridge.PhoneBridge.
 * Live audio from the watch is fed into LiveQA; model audio is discarded (muted).
 */
class WearBridgeService : WearableListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        // Рекламируем capability, чтобы часы могли найти телефон даже при разных package name
        try {
            Wearable.getCapabilityClient(this)
                .addLocalCapability(CAPABILITY_PHONE)
                .addOnSuccessListener { Log.d(TAG, "advertised $CAPABILITY_PHONE") }
                .addOnFailureListener { Log.w(TAG, "addLocalCapability failed", it) }
        } catch (e: Exception) {
            Log.w(TAG, "capability advertise", e)
        }
    }

    override fun onDestroy() {
        try {
            Wearable.getCapabilityClient(this).removeLocalCapability(CAPABILITY_PHONE)
        } catch (_: Exception) {}
        scope.cancel()
        super.onDestroy()
    }

    override fun onMessageReceived(event: MessageEvent) {
        val path = event.path
        val data = event.data ?: ByteArray(0)
        Log.d(TAG, "wear msg path=$path bytes=${data.size}")
        when (path) {
            PATH_LISTEN_START -> {
                val src = data.toString(Charsets.UTF_8).ifBlank { "phone" }
                EchoState.setMicSource(this, src)
                EchoState.setListening(this, true)
                startForegroundService(Intent(this, ListeningService::class.java).apply { action = "start" })
                WidgetTransition.animateModeChange(this)
                if (src == "watch") {
                    scope.launch { sendToWatch(PATH_CAPTURE_START, ByteArray(0)) }
                }
            }
            PATH_LISTEN_STOP -> {
                EchoState.setListening(this, false)
                stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
                WidgetTransition.animateModeChange(this)
                scope.launch { sendToWatch(PATH_CAPTURE_STOP, ByteArray(0)) }
            }
            PATH_MIC -> {
                val src = data.toString(Charsets.UTF_8)
                EchoState.setMicSource(this, src)
            }
            PATH_FAVORITE -> {
                scope.launch {
                    try {
                        val j = JSONObject(data.toString(Charsets.UTF_8))
                        val id = j.getLong("id")
                        val fav = j.getBoolean("favorite")
                        EchoDb.get(this@WearBridgeService).cards().setFavorite(id, fav)
                        pushCards()
                    } catch (e: Exception) {
                        Log.e(TAG, "favorite", e)
                    }
                }
            }
            PATH_CARDS_REQUEST -> scope.launch { pushCards() }
            PATH_LIVE_START -> scope.launch { startWatchLive() }
            PATH_LIVE_STOP -> stopWatchLive()
            PATH_LIVE_AUDIO -> {
                if (data.isNotEmpty()) LiveQA.sendAudio(data)
            }
            PATH_LISTEN_AUDIO -> {
                if (data.isNotEmpty()) ListeningService.offerWatchPcm(data)
            }
        }
    }

    private suspend fun startWatchLive() {
        if (EchoState.isLive(this)) return
        // Pause background listening
        if (EchoState.isListening(this)) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
        }
        EchoState.setLive(this, true, "Подключаюсь…")
        sendToWatch(PATH_LIVE_STATUS, "Подключаюсь…".toByteArray(Charsets.UTF_8))

        val ctxText = try {
            LiveQaContext.build(this)
        } catch (_: Exception) {
            "Ты — Эхо, голосовой помощник."
        }

        val ready = LiveQA.start(
            systemContext = ctxText,
            onAnswerChunk = { /* muted — no phone/watch speaker playback */ },
            onSubtitleChunk = { text ->
                scope.launch {
                    sendToWatch(PATH_LIVE_SUBTITLE, text.toByteArray(Charsets.UTF_8))
                }
            },
            onTurnComplete = {
                scope.launch {
                    sendToWatch(PATH_LIVE_STATUS, "Слушаю…".toByteArray(Charsets.UTF_8))
                }
            }
        )
        if (!ready) {
            EchoState.setLive(this, false)
            sendToWatch(PATH_LIVE_STATUS, "Нет связи".toByteArray(Charsets.UTF_8))
            return
        }
        EchoState.setLiveStatus(this, "Слушаю…")
        sendToWatch(PATH_LIVE_STATUS, "Слушаю…".toByteArray(Charsets.UTF_8))
    }

    private fun stopWatchLive() {
        LiveQA.stop()
        EchoState.setLive(this, false)
        scope.launch {
            sendToWatch(PATH_LIVE_STATUS, "Стоп".toByteArray(Charsets.UTF_8))
        }
    }

    private suspend fun pushCards() {
        val list = EchoDb.get(this).cards().all().take(40)
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val arr = JSONArray()
        for (c in list) {
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("time", fmt.format(Date(c.createdAt)))
                    .put("text", c.text)
                    .put("favorite", c.favorite)
            )
        }
        sendToWatch(PATH_CARDS, arr.toString().toByteArray(Charsets.UTF_8))
    }

    private suspend fun sendToWatch(path: String, data: ByteArray) {
        try {
            val capInfo = try {
                Wearable.getCapabilityClient(this)
                    .getCapability(CAPABILITY_WATCH, CapabilityClient.FILTER_REACHABLE)
                    .await()
            } catch (_: Exception) {
                null
            }
            val nodes = if (capInfo != null && capInfo.nodes.isNotEmpty()) {
                capInfo.nodes
            } else {
                Wearable.getNodeClient(this).connectedNodes.await()
            }
            val client = Wearable.getMessageClient(this)
            for (n in nodes) {
                client.sendMessage(n.id, path, data).await()
            }
        } catch (e: Exception) {
            Log.e(TAG, "sendToWatch $path", e)
        }
    }

    companion object {
        private const val TAG = "WearBridge"
        const val CAPABILITY_PHONE = "echo_phone"
        const val CAPABILITY_WATCH = "echo_watch"
        const val PATH_LISTEN_START = "/echo/listen/start"
        const val PATH_LISTEN_STOP = "/echo/listen/stop"
        const val PATH_LIVE_START = "/echo/live/start"
        const val PATH_LIVE_STOP = "/echo/live/stop"
        const val PATH_LIVE_AUDIO = "/echo/live/audio"
        const val PATH_LISTEN_AUDIO = "/echo/listen/audio"
        const val PATH_LIVE_STATUS = "/echo/live/status"
        const val PATH_LIVE_SUBTITLE = "/echo/live/subtitle"
        const val PATH_CARDS = "/echo/cards"
        const val PATH_CARDS_REQUEST = "/echo/cards/request"
        const val PATH_FAVORITE = "/echo/cards/favorite"
        const val PATH_MIC = "/echo/mic"
        const val PATH_CAPTURE_START = "/echo/listen/capture/start"
        const val PATH_CAPTURE_STOP = "/echo/listen/capture/stop"
    }
}
