package com.echo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

class EchoWidget3x1 : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(context, mgr, ids)
    }

    override fun onEnabled(context: Context) {
        WidgetUpdater.refreshAll(context)
        if (EchoState.isListening(context) || EchoState.isLive(context)) {
            WidgetUpdater.scheduleTick(context)
        }
    }

    companion object {
        private val WAVE_FRAMES = intArrayOf(
            R.drawable.widget_wave_0,
            R.drawable.widget_wave_1,
            R.drawable.widget_wave_2,
            R.drawable.widget_wave_3
        )

        fun updateAll(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_3x1)
                val live = EchoState.isLive(ctx)
                val listening = EchoState.isListening(ctx)

                if (live) {
                    rv.setViewVisibility(R.id.mode_normal, View.GONE)
                    rv.setViewVisibility(R.id.mode_live, View.VISIBLE)
                    rv.setTextViewText(R.id.widget_status, EchoState.liveStatus(ctx))
                    val frame = WAVE_FRAMES[EchoState.waveFrame(ctx) % WAVE_FRAMES.size]
                    rv.setImageViewResource(R.id.widget_wave, frame)
                    val stop = pi(ctx, 31, WidgetActionReceiver.ACTION_STOP_LIVE)
                    rv.setOnClickPendingIntent(R.id.mode_live, stop)
                    rv.setOnClickPendingIntent(R.id.widget_wave, stop)
                    rv.setOnClickPendingIntent(R.id.widget_status, stop)
                } else {
                    rv.setViewVisibility(R.id.mode_normal, View.VISIBLE)
                    rv.setViewVisibility(R.id.mode_live, View.GONE)
                    rv.setImageViewResource(
                        R.id.widget_btn,
                        if (listening) R.drawable.ic_fab_listening else R.drawable.ic_fab_idle
                    )
                    if (listening) {
                        rv.setViewVisibility(R.id.widget_timer, View.VISIBLE)
                        rv.setViewVisibility(R.id.widget_hint, View.GONE)
                        rv.setTextViewText(R.id.widget_timer, EchoState.formatTimer(ctx))
                    } else {
                        rv.setViewVisibility(R.id.widget_timer, View.GONE)
                        rv.setViewVisibility(R.id.widget_hint, View.VISIBLE)
                    }
                    val toggle = pi(ctx, 32, WidgetActionReceiver.ACTION_TOGGLE_LISTEN)
                    val livePi = pi(ctx, 33, WidgetActionReceiver.ACTION_START_LIVE)
                    rv.setOnClickPendingIntent(R.id.widget_btn, toggle)
                    // Right side: start Live (widget long-press is reserved by launcher)
                    rv.setOnClickPendingIntent(R.id.widget_hint, livePi)
                    rv.setOnClickPendingIntent(R.id.widget_timer, toggle)
                }
                mgr.updateAppWidget(id, rv)
            }
        }

        private fun pi(ctx: Context, req: Int, action: String): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, req,
                Intent(ctx, WidgetActionReceiver::class.java).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
    }
}
