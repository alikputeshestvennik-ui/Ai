package com.echo.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        try {
            when (intent?.action) {
                ACTION_TOGGLE_LISTEN -> toggleListen(context)
                WidgetUpdater.ACTION_TICK -> {
                    // Fallback only — primary updates come from ListeningService
                    if (EchoState.isListening(context)) {
                        WidgetUpdater.refreshAll(context)
                    }
                }
            }
        } finally {
            pending.finish()
        }
    }

    private fun toggleListen(ctx: Context) {
        val on = !EchoState.isListening(ctx)
        EchoState.setListening(ctx, on)
        val i = Intent(ctx, ListeningService::class.java).apply {
            action = if (on) "start" else "stop"
        }
        if (on) ctx.startForegroundService(i) else ctx.stopService(i)
        WidgetTransition.animateModeChange(ctx)
        // Ticker is owned by ListeningService when started via service;
        // if service start is delayed, still refresh once.
        if (!on) WidgetUpdater.cancelTick(ctx)
    }

    companion object {
        const val ACTION_TOGGLE_LISTEN = "com.echo.app.WIDGET_TOGGLE_LISTEN"
        const val ACTION_START_LIVE = "com.echo.app.WIDGET_START_LIVE"
        const val ACTION_STOP_LIVE = "com.echo.app.WIDGET_STOP_LIVE"
    }
}
