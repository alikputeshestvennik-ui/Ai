package com.echo.app

import android.app.Application
import com.google.android.gms.wearable.Wearable

class EchoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            Wearable.getCapabilityClient(this)
                .addLocalCapability("echo_phone")
        } catch (_: Exception) {
            // Data Layer may be temporarily unavailable; it can recover on next process start.
        }
    }
}
