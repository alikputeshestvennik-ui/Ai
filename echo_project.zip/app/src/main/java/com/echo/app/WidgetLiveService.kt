package com.echo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Headless Live QA session driven from the 3×1 widget.
 * No overlay / subtitles — only status text on the widget + Siri-wave frames.
 */
class WidgetLiveService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var recording = false
    private var recordThread: Thread? = null
    private var track: AudioTrack? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(42, notification("Эхо Live"))
        if (job == null) beginSession()
        return START_STICKY
    }

    private fun beginSession() {
        job = scope.launch {
            EchoState.setLiveStatus(this@WidgetLiveService, "Подключаюсь…")
            WidgetUpdater.refreshAll(this@WidgetLiveService)

            val ctxText = try {
                LiveQaContext.build(this@WidgetLiveService)
            } catch (_: Exception) {
                "Ты — Эхо, голосовой помощник."
            }

            ensureTrack()
            val ready = LiveQA.start(
                systemContext = ctxText,
                onAnswerChunk = { pcm ->
                    writePcm(pcm)
                    // speaker energy bumps wave via frame tick already
                },
                onSubtitleChunk = { /* no subtitles on widget */ },
                onTurnComplete = {
                    EchoState.setLiveStatus(this@WidgetLiveService, "Слушаю…")
                    WidgetUpdater.refreshAll(this@WidgetLiveService)
                }
            )
            if (!ready) {
                EchoState.setLiveStatus(this@WidgetLiveService, "Нет связи")
                WidgetUpdater.refreshAll(this@WidgetLiveService)
                return@launch
            }
            EchoState.setLiveStatus(this@WidgetLiveService, "Слушаю…")
            WidgetUpdater.refreshAll(this@WidgetLiveService)
            startMic()
        }
    }

    private fun startMic() {
        recording = true
        recordThread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(6400, minBuf)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                return@Thread
            }
            ar.startRecording()
            try {
                val buf = ShortArray(320)
                while (recording) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val s = buf[k].toInt()
                        bytes[k * 2] = (s and 0xff).toByte()
                        bytes[k * 2 + 1] = (s shr 8).toByte()
                    }
                    LiveQA.sendAudio(bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }.also { it.start() }
    }

    private fun ensureTrack() {
        if (track != null) return
        val minBuf = AudioTrack.getMinBufferSize(
            24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        track = AudioTrack.Builder()
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 4800))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track?.play()
    }

    private fun writePcm(pcm: ByteArray) {
        try {
            track?.write(pcm, 0, pcm.size)
        } catch (_: Exception) {}
    }

    private fun shutdown() {
        recording = false
        try { recordThread?.join(500) } catch (_: Exception) {}
        recordThread = null
        LiveQA.stop()
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
        job?.cancel()
        job = null
        EchoState.setLive(this, false)
        WidgetUpdater.refreshAll(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        shutdown()
        scope.cancel()
        super.onDestroy()
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = "echo_live"
        nm.createNotificationChannel(
            NotificationChannel(ch, "Эхо Live", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, ch)
            .setContentTitle("Эхо Live")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
    }
}
