package com.echo.app

import android.content.Context

/** Shared app/widget state. */
object EchoState {
    private const val PREFS = "echo_state"

    const val KEY_LISTENING = "listening"
    const val KEY_LISTEN_STARTED_AT = "listen_started_at"
    const val KEY_LIVE = "live_qa"
    const val KEY_LIVE_STATUS = "live_status"
    const val KEY_WAVE_FRAME = "wave_frame"
    const val KEY_MIC_SOURCE = "mic_source" // "watch" | "phone"


    fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun p(ctx: Context) = prefs(ctx)

    fun isListening(ctx: Context) = p(ctx).getBoolean(KEY_LISTENING, false)
    fun listenStartedAt(ctx: Context) = p(ctx).getLong(KEY_LISTEN_STARTED_AT, 0L)
    fun isLive(ctx: Context) = p(ctx).getBoolean(KEY_LIVE, false)
    fun liveStatus(ctx: Context) = p(ctx).getString(KEY_LIVE_STATUS, "Слушаю…") ?: "Слушаю…"
    fun waveFrame(ctx: Context) = p(ctx).getInt(KEY_WAVE_FRAME, 0)

    fun setListening(ctx: Context, on: Boolean) {
        p(ctx).edit()
            .putBoolean(KEY_LISTENING, on)
            .putLong(KEY_LISTEN_STARTED_AT, if (on) System.currentTimeMillis() else 0L)
            .apply()
        // Keep legacy activity prefs in sync
        ctx.getSharedPreferences("MainActivity", Context.MODE_PRIVATE)
            .edit().putBoolean("running", on).apply()
        try {
            ctx.getSharedPreferences(ctx.packageName + "_preferences", Context.MODE_PRIVATE)
                .edit().putBoolean("running", on).apply()
        } catch (_: Exception) {}
    }

    fun setLive(ctx: Context, on: Boolean, status: String = "Слушаю…") {
        p(ctx).edit()
            .putBoolean(KEY_LIVE, on)
            .putString(KEY_LIVE_STATUS, status)
            .apply()
    }

    fun setLiveStatus(ctx: Context, status: String) {
        p(ctx).edit().putString(KEY_LIVE_STATUS, status).apply()
    }

    fun micSource(ctx: Context) = p(ctx).getString(KEY_MIC_SOURCE, "phone") ?: "phone"
    fun setMicSource(ctx: Context, source: String) {
        p(ctx).edit().putString(KEY_MIC_SOURCE, source).apply()
    }

    fun nextWaveFrame(ctx: Context): Int {
        val n = (waveFrame(ctx) + 1) % 4
        p(ctx).edit().putInt(KEY_WAVE_FRAME, n).apply()
        return n
    }

    fun formatTimer(ctx: Context): String {
        val started = listenStartedAt(ctx)
        if (started <= 0L) return "00:00"
        val sec = ((System.currentTimeMillis() - started) / 1000).toInt().coerceAtLeast(0)
        val m = sec / 60
        val s = sec % 60
        return "%02d:%02d".format(m, s)
    }
}
