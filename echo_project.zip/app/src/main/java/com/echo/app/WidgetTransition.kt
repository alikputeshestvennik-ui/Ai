package com.echo.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper

/**
 * Animated transitions for the 1×1 widget:
 * ring ⇄ black square with timer + REC dot.
 */
object WidgetTransition {
    private val handler = Handler(Looper.getMainLooper())
    private var running: Runnable? = null

    enum class Mode { IDLE, LISTENING }

    private fun mode(ctx: Context) =
        if (EchoState.isListening(ctx)) Mode.LISTENING else Mode.IDLE

    private fun prev(ctx: Context): Mode {
        val v = EchoState.prefs(ctx).getString("w1_prev", Mode.IDLE.name) ?: Mode.IDLE.name
        return try { Mode.valueOf(v) } catch (_: Exception) { Mode.IDLE }
    }

    private fun save(ctx: Context, m: Mode) {
        EchoState.prefs(ctx).edit().putString("w1_prev", m.name).apply()
    }

    fun animateModeChange(ctx: Context) {
        val app = ctx.applicationContext
        val from = prev(app)
        val to = mode(app)
        save(app, to)

        running?.let { handler.removeCallbacks(it) }
        running = null

        val mgr = AppWidgetManager.getInstance(app)
        val ids = mgr.getAppWidgetIds(ComponentName(app, EchoWidget1x1::class.java))
        if (ids.isEmpty()) return

        if (from == to) {
            for (id in ids) mgr.updateAppWidget(id, EchoWidget1x1.build(app))
            return
        }

        val frames: List<Pair<Long, () -> android.widget.RemoteViews>> = when {
            from == Mode.IDLE && to == Mode.LISTENING -> listOf(
                70L to { EchoWidget1x1.build(app, forceListening = false, ringAlpha = 1f) },
                70L to { EchoWidget1x1.build(app, forceListening = false, ringAlpha = 0.3f) },
                80L to { EchoWidget1x1.build(app, forceListening = true, timerText = "00:00", recAlpha = 0.35f) },
                90L to { EchoWidget1x1.build(app, forceListening = true, timerText = "00:00", recAlpha = 0.75f) },
                100L to { EchoWidget1x1.build(app, forceListening = true, recAlpha = 1f) }
            )
            else -> listOf(
                70L to { EchoWidget1x1.build(app, forceListening = true, recAlpha = 1f) },
                70L to { EchoWidget1x1.build(app, forceListening = true, recAlpha = 0.35f) },
                80L to { EchoWidget1x1.build(app, forceListening = false, ringAlpha = 0.35f) },
                100L to { EchoWidget1x1.build(app, forceListening = false, ringAlpha = 1f) }
            )
        }

        var i = 0
        val tick = object : Runnable {
            override fun run() {
                if (i >= frames.size) {
                    for (id in ids) mgr.updateAppWidget(id, EchoWidget1x1.build(app))
                    running = null
                    return
                }
                val (delay, builder) = frames[i++]
                val rv = builder()
                for (id in ids) mgr.updateAppWidget(id, rv)
                handler.postDelayed(this, delay)
            }
        }
        running = tick
        handler.post(tick)
    }
}
