package com.echo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

class EchoWidget1x1 : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(context, mgr, ids)
    }

    override fun onEnabled(context: Context) {
        WidgetUpdater.refreshAll(context)
        if (EchoState.isListening(context)) WidgetUpdater.scheduleTick(context)
    }

    companion object {
        fun updateAll(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx))
            }
        }

        fun build(
            ctx: Context,
            forceListening: Boolean? = null,
            timerText: String? = null,
            ringAlpha: Float = 1f,
            recAlpha: Float = 1f
        ): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_1x1)
            val listening = forceListening ?: EchoState.isListening(ctx)
            val pi = PendingIntent.getBroadcast(
                ctx, 11,
                Intent(ctx, WidgetActionReceiver::class.java)
                    .setAction(WidgetActionReceiver.ACTION_TOGGLE_LISTEN),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (listening) {
                rv.setViewVisibility(R.id.widget_btn, View.GONE)
                rv.setViewVisibility(R.id.mode_recording, View.VISIBLE)
                rv.setTextViewText(
                    R.id.widget_timer,
                    timerText ?: EchoState.formatTimer(ctx)
                )
                try {
                    rv.setFloat(R.id.mode_recording, "setAlpha", recAlpha)
                    rv.setFloat(R.id.widget_timer, "setAlpha", recAlpha)
                    rv.setFloat(R.id.widget_rec_dot, "setAlpha", if (recAlpha > 0.5f) {
                        // blink REC dot via pulse phase
                        val phase = EchoState.prefs(ctx).getInt("pulse_phase", 0)
                        if (phase % 2 == 0) 1f else 0.25f
                    } else recAlpha)
                } catch (_: Exception) {}
            } else {
                rv.setViewVisibility(R.id.widget_btn, View.VISIBLE)
                rv.setViewVisibility(R.id.mode_recording, View.GONE)
                rv.setImageViewResource(R.id.widget_btn, R.drawable.ic_fab_idle)
                try {
                    rv.setFloat(R.id.widget_btn, "setAlpha", ringAlpha)
                } catch (_: Exception) {}
            }

            rv.setOnClickPendingIntent(R.id.widget_root, pi)
            rv.setOnClickPendingIntent(R.id.widget_btn, pi)
            rv.setOnClickPendingIntent(R.id.mode_recording, pi)
            rv.setOnClickPendingIntent(R.id.widget_timer, pi)
            return rv
        }
    }
}
