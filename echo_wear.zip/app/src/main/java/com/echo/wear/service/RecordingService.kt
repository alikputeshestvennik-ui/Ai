package com.echo.wear.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import android.util.Log
import androidx.core.app.ActivityCompat
import com.echo.wear.bridge.PhoneBridge
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground Service for recording audio on the watch.
 * Required on Wear OS 3+ for microphone access in background.
 */
class RecordingService : Service() {

    private val recording = AtomicBoolean(false)
    private var recordThread: Thread? = null
    private var targetPath: String = PhoneBridge.PATH_LIVE_AUDIO

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                targetPath = intent.getStringExtra(EXTRA_PATH) ?: PhoneBridge.PATH_LIVE_AUDIO
                startRecording()
            }
            ACTION_STOP -> {
                stopRecording()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecording() {
        if (recording.getAndSet(true)) return

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
            != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "RECORD_AUDIO permission not granted")
            stopSelf()
            return
        }

        recordThread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val ar = try {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC, 16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 6400)
                )
            } catch (e: Exception) {
                Log.e(TAG, "AudioRecord creation failed", e)
                recording.set(false)
                return@Thread
            }

            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord not initialized")
                ar.release()
                recording.set(false)
                return@Thread
            }

            ar.startRecording()
            try {
                val buf = ShortArray(320) // 20ms at 16kHz
                while (recording.get()) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    
                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val s = buf[k].toInt()
                        bytes[k * 2] = (s and 0xff).toByte()
                        bytes[k * 2 + 1] = (s shr 8).toByte()
                    }
                    
                    PhoneBridge.sendAudio(targetPath, bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
                recording.set(false)
            }
        }.also { it.start() }
    }

    private fun stopRecording() {
        recording.set(false)
        try { recordThread?.join(400) } catch (_: Exception) {}
        recordThread = null
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Запись",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Индикатор активной записи"
        }
        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Эхо слушает")
            .setContentText("Запись активна")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "RecordingService"
        private const val CHANNEL_ID = "echo_recording"
        private const val NOTIFICATION_ID = 1
        const val ACTION_START = "com.echo.wear.START_RECORDING"
        const val ACTION_STOP = "com.echo.wear.STOP_RECORDING"
        const val EXTRA_PATH = "path"
    }
}
