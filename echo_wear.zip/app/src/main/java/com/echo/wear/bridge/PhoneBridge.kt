package com.echo.wear.bridge

import android.content.Context
import android.content.Intent
import android.util.Log
import com.echo.wear.service.RecordingService
import com.google.android.gms.wearable.CapabilityClient
import com.google.android.gms.wearable.CapabilityInfo
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

enum class MicSource { WATCH, PHONE }

data class WatchCard(
    val id: Long,
    val time: String,
    val text: String,
    val favorite: Boolean
)

/**
 * Wear ↔ phone bridge (MessageClient + CapabilityClient).
 * Live: watch mic PCM → phone; subtitles/status ← phone; no audio out.
 */
object PhoneBridge : MessageClient.OnMessageReceivedListener, CapabilityClient.OnCapabilityChangedListener {

    const val PATH_LISTEN_START = "/echo/listen/start"
    const val PATH_LISTEN_STOP = "/echo/listen/stop"
    const val PATH_LISTEN_AUDIO = "/echo/listen/audio"
    const val PATH_LIVE_START = "/echo/live/start"
    const val PATH_LIVE_STOP = "/echo/live/stop"
    const val PATH_LIVE_AUDIO = "/echo/live/audio"
    const val PATH_LIVE_STATUS = "/echo/live/status"
    const val PATH_LIVE_SUBTITLE = "/echo/live/subtitle"
    const val PATH_CARDS = "/echo/cards"
    const val PATH_CARDS_REQUEST = "/echo/cards/request"
    const val PATH_FAVORITE = "/echo/cards/favorite"
    const val PATH_MIC = "/echo/mic"

    /** Capability, которую рекламирует телефонное приложение */
    private const val CAPABILITY_PHONE = "echo_phone"
    /** Capability, которую рекламируют часы */
    private const val CAPABILITY_WATCH = "echo_watch"

    private const val TAG = "PhoneBridge"

    private var appCtx: Context? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollJob: Job? = null

    var onStatus: ((String) -> Unit)? = null
    var onSubtitle: ((String) -> Unit)? = null
    var onCards: ((List<WatchCard>) -> Unit)? = null
    /** true = есть хотя бы один reachable node (телефон рядом) */
    var onConnectionChanged: ((Boolean) -> Unit)? = null

    @Volatile
    var isConnected: Boolean = false
        private set

    private val cardCache = CopyOnWriteArrayList<WatchCard>()
    private val phoneNodeIds = CopyOnWriteArrayList<String>()

    fun init(context: Context) {
        if (appCtx != null) return
        appCtx = context.applicationContext
        val ctx = context.applicationContext

        Wearable.getMessageClient(ctx).addListener(this)

        // Рекламируем, что на часах есть Echo
        try {
            Wearable.getCapabilityClient(ctx)
                .addLocalCapability(CAPABILITY_WATCH)
                .addOnSuccessListener { Log.d(TAG, "advertised $CAPABILITY_WATCH") }
                .addOnFailureListener { Log.w(TAG, "addLocalCapability failed", it) }
        } catch (e: Exception) {
            Log.w(TAG, "capability advertise", e)
        }

        Wearable.getCapabilityClient(ctx)
            .addListener(this, CAPABILITY_PHONE)

        // Первичный поиск + периодический опрос
        scope.launch { refreshNodes() }
        startPolling()
        requestCards()
    }

    fun dispose(context: Context) {
        pollJob?.cancel()
        pollJob = null
        try {
            Wearable.getMessageClient(context.applicationContext).removeListener(this)
            Wearable.getCapabilityClient(context.applicationContext).removeListener(this)
            Wearable.getCapabilityClient(context.applicationContext)
                .removeLocalCapability(CAPABILITY_WATCH)
        } catch (_: Exception) {}
        stopMicStream()
        appCtx = null
        setConnected(false)
    }

    override fun onMessageReceived(event: MessageEvent) {
        val text = event.data?.toString(Charsets.UTF_8) ?: ""
        when (event.path) {
            PATH_LIVE_STATUS -> onStatus?.invoke(text)
            PATH_LIVE_SUBTITLE -> onSubtitle?.invoke(text)
            PATH_CARDS -> parseCards(text)
            "/echo/listen/capture/start" -> startMicStream(PATH_LISTEN_AUDIO)
            "/echo/listen/capture/stop" -> stopMicStream()
        }
    }

    override fun onCapabilityChanged(info: CapabilityInfo) {
        Log.d(TAG, "capability ${info.name} nodes=${info.nodes.size}")
        scope.launch { refreshNodes() }
    }

    /**
     * Send audio bytes to phone via MessageClient.
     * Called from RecordingService.
     */
    fun sendAudio(path: String, data: ByteArray) {
        scope.launch {
            val ctx = appCtx ?: return@launch
            try {
                val targets = targetNodeIds(ctx)
                if (targets.isEmpty()) return@launch
                val client = Wearable.getMessageClient(ctx)
                for (id in targets) {
                    client.sendMessage(id, path, data).await()
                }
            } catch (e: Exception) {
                Log.e(TAG, "sendAudio $path", e)
            }
        }
    }

    private fun parseCards(json: String) {
        try {
            val arr = JSONArray(json)
            val list = ArrayList<WatchCard>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    WatchCard(
                        id = o.getLong("id"),
                        time = o.optString("time"),
                        text = o.optString("text"),
                        favorite = o.optBoolean("favorite")
                    )
                )
            }
            cardCache.clear()
            cardCache.addAll(list)
            onCards?.invoke(list)
        } catch (e: Exception) {
            Log.e(TAG, "parseCards", e)
        }
    }

    fun startListen(source: MicSource) {
        scope.launch {
            val ok = send(PATH_LISTEN_START, source.name.lowercase().toByteArray(Charsets.UTF_8))
            if (!ok) {
                onStatus?.invoke("Нет связи с телефоном")
                return@launch
            }
            if (source == MicSource.WATCH) {
                startMicStream(path = PATH_LISTEN_AUDIO)
            } else {
                stopMicStream()
            }
        }
    }

    fun stopListen() {
        scope.launch { send(PATH_LISTEN_STOP, ByteArray(0)) }
        stopMicStream()
    }

    fun startLive(
        onStatus: (String) -> Unit,
        onSubtitle: (String) -> Unit,
        mutePhoneAudio: Boolean = true
    ) {
        this.onStatus = onStatus
        this.onSubtitle = onSubtitle
        scope.launch {
            val ok = send(PATH_LIVE_START, byteArrayOf(if (mutePhoneAudio) 1 else 0))
            if (!ok) {
                onStatus("Нет связи с телефоном")
                return@launch
            }
            startMicStream(PATH_LIVE_AUDIO)
        }
    }

    fun stopLive() {
        stopMicStream()
        scope.launch { send(PATH_LIVE_STOP, ByteArray(0)) }
        onStatus = null
        onSubtitle = null
    }

    fun setFavorite(id: Long, favorite: Boolean) {
        scope.launch {
            val body = JSONObject().put("id", id).put("favorite", favorite).toString()
            send(PATH_FAVORITE, body.toByteArray(Charsets.UTF_8))
        }
    }

    fun setMicSource(source: MicSource) {
        scope.launch {
            send(PATH_MIC, source.name.lowercase().toByteArray(Charsets.UTF_8))
        }
    }

    fun requestCards() {
        scope.launch { send(PATH_CARDS_REQUEST, ByteArray(0)) }
    }

    fun cachedCards(): List<WatchCard> = cardCache.toList()

    /** @return true если хотя бы одному узлу сообщение ушло */
    private suspend fun send(path: String, data: ByteArray): Boolean {
        val ctx = appCtx ?: return false
        try {
            val targets = targetNodeIds(ctx)
            if (targets.isEmpty()) {
                Log.w(TAG, "no connected phone node for $path")
                setConnected(false)
                return false
            }
            val client = Wearable.getMessageClient(ctx)
            var any = false
            for (id in targets) {
                try {
                    client.sendMessage(id, path, data).await()
                    any = true
                } catch (e: Exception) {
                    Log.e(TAG, "send $path to $id", e)
                }
            }
            setConnected(any)
            return any
        } catch (e: Exception) {
            Log.e(TAG, "send $path", e)
            setConnected(false)
            return false
        }
    }

    private suspend fun targetNodeIds(ctx: Context): List<String> {
        // Сначала capability (надёжнее при разных package name)
        try {
            val info = Wearable.getCapabilityClient(ctx)
                .getCapability(CAPABILITY_PHONE, CapabilityClient.FILTER_REACHABLE)
                .await()
            val ids = info.nodes.map { it.id }
            if (ids.isNotEmpty()) {
                phoneNodeIds.clear()
                phoneNodeIds.addAll(ids)
                return ids
            }
        } catch (e: Exception) {
            Log.w(TAG, "getCapability $CAPABILITY_PHONE", e)
        }
        // Fallback: все nearby-узлы
        return try {
            Wearable.getNodeClient(ctx).connectedNodes.await().map { it.id }
        } catch (e: Exception) {
            Log.w(TAG, "connectedNodes", e)
            emptyList()
        }
    }

    private suspend fun refreshNodes() {
        val ctx = appCtx ?: return
        val ids = targetNodeIds(ctx)
        val was = isConnected
        val now = ids.isNotEmpty()
        if (now) {
            phoneNodeIds.clear()
            phoneNodeIds.addAll(ids)
        }
        setConnected(now)
        if (now && !was) {
            Log.d(TAG, "phone connected: $ids")
            requestCards()
        } else if (!now && was) {
            Log.w(TAG, "phone disconnected")
        }
    }

    private fun setConnected(value: Boolean) {
        if (isConnected == value) return
        isConnected = value
        onConnectionChanged?.invoke(value)
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch {
            while (isActive) {
                delay(8_000)
                refreshNodes()
            }
        }
    }

    private fun startMicStream(path: String = PATH_LIVE_AUDIO) {
        stopMicStream()
        val ctx = appCtx ?: return
        val intent = Intent(ctx, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra(RecordingService.EXTRA_PATH, path)
        }
        try {
            ctx.startForegroundService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startMicStream", e)
        }
    }

    private fun stopMicStream() {
        val ctx = appCtx ?: return
        val intent = Intent(ctx, RecordingService::class.java).apply {
            action = RecordingService.ACTION_STOP
        }
        try {
            ctx.startService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "stopMicStream", e)
        }
    }
}
