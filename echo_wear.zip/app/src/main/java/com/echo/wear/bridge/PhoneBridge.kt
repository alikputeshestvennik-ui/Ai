package com.echo.wear.bridge

import android.content.Context
import android.content.Intent
import android.util.Log
import com.echo.wear.service.RecordingService
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

enum class MicSource { WATCH, PHONE }

data class WatchCard(
    val id: Long,
    val time: String,
    val text: String,
    val favorite: Boolean
)

/**
 * Wear ↔ phone bridge (MessageClient).
 * Live: watch mic PCM → phone; subtitles/status ← phone; no audio out.
 */
object PhoneBridge : MessageClient.OnMessageReceivedListener {

    const val PATH_LISTEN_START = "/echo/listen/start"
    const val PATH_LISTEN_STOP = "/echo/listen/stop"
    const val PATH_LISTEN_AUDIO = "/echo/listen/audio"
    const val PATH_LIVE_START = "/echo/live/start"
    const val PATH_LIVE_STOP = "/echo/live/stop"
    const val PATH_LIVE_AUDIO = "/echo/live/audio"
    const val PATH_LIVE_STATUS = "/echo/live/status"
    const val PATH_LIVE_SUBTITLE = "/echo/live/subtitle"
    const val PATH_CARDS = "/echo/cards"
    const val PATH_CARDS_REQUEST = "/echo/cards/request"
    const val PATH_FAVORITE = "/echo/cards/favorite"
    const val PATH_MIC = "/echo/mic"

    private const val TAG = "PhoneBridge"

    private var appCtx: Context? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var onStatus: ((String) -> Unit)? = null
    var onSubtitle: ((String) -> Unit)? = null
    var onCards: ((List<WatchCard>) -> Unit)? = null

    private val cardCache = CopyOnWriteArrayList<WatchCard>()

    fun init(context: Context) {
        if (appCtx != null) return
        appCtx = context.applicationContext
        Wearable.getMessageClient(context.applicationContext).addListener(this)
        requestCards()
    }

    fun dispose(context: Context) {
        try {
            Wearable.getMessageClient(context.applicationContext).removeListener(this)
        } catch (_: Exception) {}
        stopMicStream()
        appCtx = null
    }

    override fun onMessageReceived(event: MessageEvent) {
        val text = event.data?.toString(Charsets.UTF_8) ?: ""
        when (event.path) {
            PATH_LIVE_STATUS -> onStatus?.invoke(text)
            PATH_LIVE_SUBTITLE -> onSubtitle?.invoke(text)
            PATH_CARDS -> parseCards(text)
            "/echo/listen/capture/start" -> startMicStream(PATH_LISTEN_AUDIO)
            "/echo/listen/capture/stop" -> stopMicStream()
        }
    }

    /**
     * Send audio bytes to phone via MessageClient.
     * Called from RecordingService.
     */
    fun sendAudio(path: String, data: ByteArray) {
        scope.launch {
            val ctx = appCtx ?: return@launch
            try {
                val nodes = Wearable.getNodeClient(ctx).connectedNodes.await()
                val client = Wearable.getMessageClient(ctx)
                for (n in nodes) {
                    client.sendMessage(n.id, path, data).await()
                }
            } catch (e: Exception) {
                Log.e(TAG, "sendAudio $path", e)
            }
        }
    }

    private fun parseCards(json: String) {
        try {
            val arr = JSONArray(json)
            val list = ArrayList<WatchCard>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    WatchCard(
                        id = o.getLong("id"),
                        time = o.optString("time"),
                        text = o.optString("text"),
                        favorite = o.optBoolean("favorite")
                    )
                )
            }
            cardCache.clear()
            cardCache.addAll(list)
            onCards?.invoke(list)
        } catch (e: Exception) {
            Log.e(TAG, "parseCards", e)
        }
    }

    fun startListen(source: MicSource) {
        scope.launch {
            send(PATH_LISTEN_START, source.name.lowercase().toByteArray(Charsets.UTF_8))
            if (source == MicSource.WATCH) {
                startMicStream(path = "/echo/listen/audio")
            } else {
                stopMicStream()
            }
        }
    }

    fun stopListen() {
        scope.launch { send(PATH_LISTEN_STOP, ByteArray(0)) }
        stopMicStream()
    }

    fun startLive(
        onStatus: (String) -> Unit,
        onSubtitle: (String) -> Unit,
        mutePhoneAudio: Boolean = true
    ) {
        this.onStatus = onStatus
        this.onSubtitle = onSubtitle
        scope.launch {
            send(PATH_LIVE_START, byteArrayOf(if (mutePhoneAudio) 1 else 0))
            startMicStream(PATH_LIVE_AUDIO)
        }
    }

    fun stopLive() {
        stopMicStream()
        scope.launch { send(PATH_LIVE_STOP, ByteArray(0)) }
        onStatus = null
        onSubtitle = null
    }

    fun setFavorite(id: Long, favorite: Boolean) {
        scope.launch {
            val body = JSONObject().put("id", id).put("favorite", favorite).toString()
            send(PATH_FAVORITE, body.toByteArray(Charsets.UTF_8))
        }
    }

    fun setMicSource(source: MicSource) {
        scope.launch {
            send(PATH_MIC, source.name.lowercase().toByteArray(Charsets.UTF_8))
        }
    }

    fun requestCards() {
        scope.launch { send(PATH_CARDS_REQUEST, ByteArray(0)) }
    }

    fun cachedCards(): List<WatchCard> = cardCache.toList()

    private suspend fun send(path: String, data: ByteArray) {
        val ctx = appCtx ?: return
        try {
            val nodes = Wearable.getNodeClient(ctx).connectedNodes.await()
            if (nodes.isEmpty()) {
                Log.w(TAG, "no connected phone node")
                onStatus?.invoke("Нет связи с телефоном")
                return
            }
            val client = Wearable.getMessageClient(ctx)
            for (n in nodes) {
                client.sendMessage(n.id, path, data).await()
            }
        } catch (e: Exception) {
            Log.e(TAG, "send $path", e)
            onStatus?.invoke("Ошибка связи")
        }
    }

    private fun startMicStream(path: String = PATH_LIVE_AUDIO) {
        stopMicStream()
        val ctx = appCtx ?: return
        val intent = Intent(ctx, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra(RecordingService.EXTRA_PATH, path)
        }
        try {
            ctx.startForegroundService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startMicStream", e)
        }
    }

    private fun stopMicStream() {
        val ctx = appCtx ?: return
        val intent = Intent(ctx, RecordingService::class.java).apply {
            action = RecordingService.ACTION_STOP
        }
        try {
            ctx.startService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "stopMicStream", e)
        }
    }
}
