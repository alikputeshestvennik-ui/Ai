package com.echo.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var cards: LinearLayout
    private var selectedTab = 0
    private var currentSearchQuery = ""

    private val bg = Color.BLACK
    private val panel = Color.rgb(18, 19, 23)
    private val primaryText = Color.rgb(245, 247, 250)
    private val muted = Color.rgb(145, 149, 160)
    private val accent = Color.rgb(92, 150, 255)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }

        buildUi()
        refreshLoop()
        DigestAlarmReceiver.schedule(this)

        lifecycleScope.launch {
            MemoryExtraction.runIfDue(this@MainActivity)
            if (selectedTab == 1) loadMemory()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun label(value: String, size: Float, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            includeFontPadding = false
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(10))
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val brand = label("Эхо", 34f, primaryText).apply {
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        header.addView(brand)

        status = label("Готово", 15f, muted)
        header.addView(status, LinearLayout.LayoutParams(-1, dp(28)))

        val search = EditText(this).apply {
            hint = "Искать в записях за всё время..."
            setHintTextColor(Color.rgb(95, 99, 110))
            setTextColor(primaryText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(panel, 16)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val query = s?.toString()?.trim() ?: ""
                    currentSearchQuery = query
                    filterCards(query)
                }
            })
        }
        header.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(10)
        })

        root.addView(header)

        val content = FrameLayout(this)
        cards = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, dp(90))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(cards)
        }
        content.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val fab = TextView(this).apply {
            text = "●"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Color.WHITE)
            background = rounded(accent, 50)
            elevation = dp(8).toFloat()
        }
        attachFabGesture(fab)
        val fabParams = FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabParams.bottomMargin = dp(66)
        content.addView(fab, fabParams)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            background = ColorDrawableCompat(panel)
        }

        val feed = navItem("Лента", 0)
        val memory = navItem("Память", 1)
        val settings = navItem("Настройки", 2)
        nav.addView(feed, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(memory, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(settings, LinearLayout.LayoutParams(0, dp(52), 1f))

        root.addView(nav)
        setContentView(root)
        selectTab(0)
    }

    private fun navItem(title: String, tab: Int): TextView =
        label(title, 13f, muted).apply {
            gravity = Gravity.CENTER
            setOnClickListener { selectTab(tab) }
        }

    private fun selectTab(tab: Int) {
        selectedTab = tab
        when (tab) {
            0 -> {
                status.text = if (getPreferences(0).getBoolean("running", false))
                    "Эхо слушает..." else "Готово"
                loadCards()
            }
            1 -> {
                status.text = "Багаж фактов"
                loadMemory()
            }
            2 -> {
                status.text = "Настройки"
                cards.removeAllViews()
                addSetting("Аудио", "Хранить оригинальные записи 72 часа")
                addSetting("Поиск", "Контекст последней недели")
                addSetting("Язык", "Автоматический")
            }
        }
    }

    private fun addEmpty(message: String) {
        cards.addView(label(message, 16f, muted).apply {
            setPadding(dp(4), dp(30), dp(4), dp(30))
        })
    }

    private fun addSetting(title: String, subtitle: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(panel, 18)
        }
        row.addView(label(title, 16f, primaryText))
        row.addView(label(subtitle, 13f, muted).apply {
            setPadding(0, dp(5), 0, 0)
        })
        cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })
    }

    private fun loadCards() {
        lifecycleScope.launch {
            val list = EchoDb.get(this@MainActivity).cards().all()
            cards.removeAllViews()
            if (list.isEmpty()) {
                addEmpty("Пока нет записей.\nНажми ● и начни говорить.")
                return@launch
            }
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            list.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(panel, 18)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                }
                val star = label(if (c.favorite) "★" else "", 13f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 12f, muted),
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 16f, primaryText).apply {
                    setPadding(0, dp(7), 0, 0)
                })
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    private fun loadMemory() {
        cards.removeAllViews()
        addDaySummarySection()
        addMemoryRefreshButton()

        lifecycleScope.launch {
            val facts = EchoDb.get(this@MainActivity).memory().all()
            if (facts.isEmpty()) {
                addEmpty("Здесь появятся устойчивые факты, которые Эхо запомнило.")
                return@launch
            }

            var lastCategory = ""
            facts.forEach { f ->
                if (f.category != lastCategory) {
                    lastCategory = f.category
                    cards.addView(label(f.category.replaceFirstChar { it.uppercase() }, 13f, accent).apply {
                        setPadding(dp(4), dp(14), dp(4), dp(6))
                    })
                }
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(panel, 18)
                }
                row.addView(label(f.subject, 12f, muted))
                row.addView(label(f.fact, 16f, primaryText).apply {
                    setPadding(0, dp(6), 0, 0)
                })
                cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
            }
        }
    }

    // "Анализ дня" -- an artistic recap of today's cards, sitting above the
    // long-term memory list. Shows the cached digest instantly (if any) while
    // a fresh one is fetched in the background, throttled to once an hour.
    private fun addDaySummarySection() {
        cards.addView(label("Анализ дня", 13f, accent).apply {
            setPadding(dp(4), 0, dp(4), dp(6))
        })

        val body = label("Собираю впечатления за сегодня...", 15f, primaryText)
        val caption = label("", 11f, muted).apply { setPadding(0, dp(8), 0, 0) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(panel, 18)
        }
        card.addView(body)
        card.addView(caption)
        cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(20)
        })

        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        fun show(result: DaySummary.Result) {
            body.text = result.text
            caption.text = "Обновлено в ${timeFmt.format(Date(result.generatedAt))}" +
                if (result.isFinal) " · итог дня зафиксирован" else ""
        }

        lifecycleScope.launch {
            // Avoid a "Собираю..." flash on every reopen if we already have something.
            val cachedResult = DaySummary.cached(this@MainActivity)
            cachedResult?.let { show(it) }

            val result = DaySummary.runIfDue(this@MainActivity)
            if (result != null) {
                show(result)
            } else if (cachedResult == null) {
                body.text = "Пока рановато подводить итоги — скажи что-нибудь вслух."
                caption.text = ""
            }
        }
    }

    private fun addMemoryRefreshButton() {
        val btn = Button(this).apply {
            text = "Обновить память"
            setOnClickListener {
                isEnabled = false
                text = "Извлекаю факты..."
                lifecycleScope.launch {
                    val added = MemoryExtraction.runNow(this@MainActivity)
                    Toast.makeText(
                        this@MainActivity,
                        if (added > 0) "Новых фактов: $added" else "Новых фактов не найдено",
                        Toast.LENGTH_SHORT
                    ).show()
                    if (selectedTab == 1) loadMemory()
                }
            }
        }
        cards.addView(btn, LinearLayout.LayoutParams(-1, dp(48)).apply {
            bottomMargin = dp(16)
        })
    }

    // Tap = play back the recording (tap again while it's playing = stop it),
    // long-press = copy the text, swipe left = delete the card + its audio,
    // swipe right = toggle favorite (snaps back, doesn't remove the card).
    private fun attachCardGestures(view: View, card: SpeechCard, star: TextView) {
        var isFavorite = card.favorite

        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (playingCardId == card.id && isPlaying) {
                    stopPlayback()
                } else {
                    playCard(card)
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Эхо", card.text))
                Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
            }
        })

        var downX = 0f
        var downY = 0f
        var dragging = false

        view.setOnTouchListener { v, event ->
            gesture.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!dragging && abs(dx) > dp(16) && abs(dx) > abs(dy)) {
                        dragging = true
                        v.parent.requestDisallowInterceptTouchEvent(true)
                    }
                    if (dragging) {
                        v.translationX = dx
                        // Fade only previews the delete (left) direction.
                        v.alpha = if (dx < 0) {
                            1f - (-dx / v.width.coerceAtLeast(1)).coerceIn(0f, 0.8f)
                        } else 1f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        val dx = event.rawX - downX
                        when {
                            dx < -v.width * 0.35f -> {
                                v.animate().translationX(-v.width.toFloat()).alpha(0f)
                                    .setDuration(180)
                                    .withEndAction { deleteCard(card, v) }
                                    .start()
                            }
                            dx > v.width * 0.35f -> {
                                isFavorite = !isFavorite
                                star.text = if (isFavorite) "★" else ""
                                lifecycleScope.launch {
                                    EchoDb.get(this@MainActivity).cards().setFavorite(card.id, isFavorite)
                                }
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                            else -> {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                        }
                    }
                    dragging = false
                    true
                }
                else -> true
            }
        }
    }

    private fun deleteCard(card: SpeechCard, view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
        stopPlayback()
        lifecycleScope.launch {
            EchoDb.get(this@MainActivity).cards().delete(card.id)
            card.audioPath?.let { path -> try { File(path).delete() } catch (_: Exception) {} }
        }
    }

    // Raw 16 kHz / mono / 16-bit PCM playback of a card's saved recording.
    private var playThread: Thread? = null
    @Volatile private var isPlaying = false
    @Volatile private var playingCardId: Long? = null

    private fun playCard(card: SpeechCard) {
        val path = card.audioPath
        if (path == null) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists() || file.length() == 0L) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }

        stopPlayback()
        isPlaying = true
        playingCardId = card.id
        playThread = Thread {
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    16000,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 4096),
                    AudioTrack.MODE_STREAM
                )
                track.play()
                file.inputStream().use { input ->
                    val buf = ByteArray(3200)
                    while (isPlaying) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        track.write(buf, 0, n)
                    }
                }
                track.stop()
                track.release()
            } catch (e: Exception) {
                android.util.Log.e("EchoPlayback", "Playback failed", e)
            } finally {
                isPlaying = false
                if (playingCardId == card.id) playingCardId = null
            }
        }
        playThread?.start()
    }

    private fun stopPlayback() {
        isPlaying = false
        try { playThread?.join(200) } catch (_: Exception) {}
        playThread = null
        playingCardId = null
    }

    override fun onStop() {
        stopPlayback()
        if (qaActive) stopLiveQA()
        super.onStop()
    }

    private fun refreshLoop() {
        lifecycleScope.launch {
            while (!isFinishing) {
                if (selectedTab == 0) {
                    // Don't wipe an active search result with a full reload.
                    if (currentSearchQuery.isBlank()) {
                        loadCards()
                    } else {
                        filterCards(currentSearchQuery)
                    }
                }
                delay(2500)
            }
        }
    }

    private fun toggle() {
        val running = getPreferences(0).getBoolean("running", false)
        val intent = Intent(this, ListeningService::class.java).apply {
            action = if (running) "stop" else "start"
        }
        if (running) {
            stopService(intent)
        } else {
            startForegroundService(intent)
        }
        getPreferences(0).edit().putBoolean("running", !running).apply()
        status.text = if (running) "Готово" else "Эхо слушает..."
    }

    // Long-press the FAB to open the overlay and start recording a spoken
    // question; swipe up (while still holding) to send it; releasing without
    // swiping up cancels. A plain tap still toggles background listening.
    private fun attachFabGesture(fab: View) {
        // Long-press opens a continuous Live QA session.
        // A second tap while the session is active closes it.
        // A plain short tap (no active QA) still toggles background listening.
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (qaActive) {
                    // Second tap — close the running session
                    stopLiveQA()
                } else {
                    toggle()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!qaActive) startLiveQA()
            }
        })

        fab.setOnTouchListener { _, event ->
            gesture.onTouchEvent(event)
            true
        }
    }

    @Volatile private var qaActive = false
    @Volatile private var qaRecording = false
    private var qaRecordThread: Thread? = null
    private var qaOverlay: View? = null
    private var qaStatus: TextView? = null
    private var qaAnswer: TextView? = null

    // Live QA model audio playback (Gemini Live returns 24 kHz PCM mono).
    private var qaTrack: AudioTrack? = null
    private val qaTrackLock = Any()

    // Two AudioRecord sessions on the mic at once is unreliable across
    // devices -- pause background listening while a question is being asked,
    // and always resume it (if it was running) once the overlay closes.
    private var qaPausedBackgroundListening = false

    private fun startLiveQA() {
        qaActive = true
        qaPausedBackgroundListening = getPreferences(0).getBoolean("running", false)
        if (qaPausedBackgroundListening) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
        }
        showQaOverlay()
        ensureQaTrack()

        lifecycleScope.launch {
            val context = LiveQaContext.build(this@MainActivity)
            val ready = LiveQA.start(
                systemContext = context,
                onAnswerChunk = { pcm ->
                    // Model audio: play PCM immediately (off the UI thread).
                    writeQaAudio(pcm)
                    runOnUiThread {
                        qaStatus?.text = "Эхо отвечает..."
                    }
                },
                onSubtitleChunk = { text ->
                    runOnUiThread {
                        qaAnswer?.append(text)
                    }
                },
                onTurnComplete = {
                    // Session stays open — ready for the next question
                    runOnUiThread { qaStatus?.text = "Слушаю... нажми ещё раз, чтобы закрыть" }
                }
            )
            if (!qaActive) return@launch
            if (!ready) {
                runOnUiThread { qaStatus?.text = "Не удалось подключиться к Эхо." }
                return@launch
            }
            runOnUiThread { qaStatus?.text = "Слушаю... нажми ещё раз, чтобы закрыть" }
            beginQaRecording()
        }
    }

    // Closes the ongoing Live QA session (triggered by second tap on FAB or ЗАКРЫТЬ button).
    private fun stopLiveQA() {
        qaActive = false
        qaRecording = false
        LiveQA.stop()
        releaseQaTrack()
        closeQaOverlay()
        if (qaPausedBackgroundListening) {
            qaPausedBackgroundListening = false
            startForegroundService(Intent(this, ListeningService::class.java).apply { action = "start" })
        }
    }

    private fun ensureQaTrack() {
        synchronized(qaTrackLock) {
            if (qaTrack != null) return
            // Gemini Live AUDIO modality delivers 24 kHz 16-bit mono PCM.
            val sampleRate = 24000
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4800),
                AudioTrack.MODE_STREAM
            )
            track.play()
            qaTrack = track
        }
    }

    private fun writeQaAudio(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        synchronized(qaTrackLock) {
            val track = qaTrack ?: return
            try {
                track.write(pcm, 0, pcm.size)
            } catch (e: Exception) {
                android.util.Log.e("EchoLiveQA", "writeQaAudio failed", e)
            }
        }
    }

    private fun releaseQaTrack() {
        synchronized(qaTrackLock) {
            try {
                qaTrack?.stop()
            } catch (_: Exception) {}
            try {
                qaTrack?.release()
            } catch (_: Exception) {}
            qaTrack = null
        }
    }

    private fun beginQaRecording() {
        qaRecording = true
        qaRecordThread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(6400, minBuf)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                return@Thread
            }
            ar.startRecording()
            try {
                val buf = ShortArray(320)
                while (qaRecording) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val s = buf[k].toInt()
                        bytes[k * 2] = (s and 0xff).toByte()
                        bytes[k * 2 + 1] = (s shr 8).toByte()
                    }
                    LiveQA.sendAudio(bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }
        qaRecordThread?.start()
    }

    // filterCards: re-renders the cards list filtered by query (case-insensitive substring match).
    // Empty query restores the full list for the current tab.
    private fun filterCards(query: String) {
        if (query.isEmpty()) {
            when (selectedTab) {
                0 -> loadCards()
                1 -> loadMemory()
            }
            return
        }
        lifecycleScope.launch {
            val db = EchoDb.get(this@MainActivity)
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            val lower = query.lowercase()
            val results = db.cards().all().filter { it.text.lowercase().contains(lower) }
            cards.removeAllViews()
            if (results.isEmpty()) {
                addEmpty("Ничего не найдено по запросу «$query»")
                return@launch
            }
            results.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(panel, 18)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                }
                val star = label(if (c.favorite) "★" else "", 13f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 12f, muted),
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 16f, primaryText).apply {
                    setPadding(0, dp(7), 0, 0)
                })
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    private fun showQaOverlay() {
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(30), dp(28), dp(30))
            setBackgroundColor(Color.argb(245, 5, 6, 8))
        }
        val title = label("Эхо", 24f, primaryText).apply { gravity = Gravity.CENTER }
        val pulse = label("◉", 80f, accent).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(30), 0, dp(16))
        }
        val status = label("Подключаюсь...", 15f, muted).apply { gravity = Gravity.CENTER }
        val answer = label("", 17f, primaryText).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        val close = Button(this).apply {
            text = "ЗАКРЫТЬ"
            setOnClickListener { stopLiveQA() }
        }

        overlay.addView(title)
        overlay.addView(pulse)
        overlay.addView(status)
        overlay.addView(answer)
        overlay.addView(close, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(28)
        })

        qaOverlay = overlay
        qaStatus = status
        qaAnswer = answer
        addContentView(overlay, ViewGroup.LayoutParams(-1, -1))
    }

    private fun closeQaOverlay() {
        (qaOverlay?.parent as? ViewGroup)?.removeView(qaOverlay)
        qaOverlay = null
        qaStatus = null
        qaAnswer = null
    }

    private object ColorDrawableCompat {
        operator fun invoke(color: Int) = android.graphics.drawable.ColorDrawable(color)
    }
}
