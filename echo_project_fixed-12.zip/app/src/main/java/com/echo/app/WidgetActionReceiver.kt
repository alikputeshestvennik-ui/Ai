package com.echo.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        try {
            when (intent?.action) {
                ACTION_TOGGLE_LISTEN -> toggleListen(context)
                WidgetUpdater.ACTION_TICK -> onTick(context)
                // keep old actions no-op for safety
                ACTION_START_LIVE, ACTION_STOP_LIVE -> { }
            }
        } finally {
            pending.finish()
        }
    }

    private fun onTick(ctx: Context) {
        if (!EchoState.isListening(ctx)) {
            WidgetUpdater.cancelTick(ctx)
            WidgetUpdater.refreshAll(ctx)
            return
        }
        val phase = EchoState.prefs(ctx).getInt("pulse_phase", 0) + 1
        EchoState.prefs(ctx).edit().putInt("pulse_phase", phase).apply()
        WidgetUpdater.refreshAll(ctx)
        WidgetUpdater.scheduleTick(ctx)
    }

    private fun toggleListen(ctx: Context) {
        val on = !EchoState.isListening(ctx)
        EchoState.setListening(ctx, on)
        val i = Intent(ctx, ListeningService::class.java).apply {
            action = if (on) "start" else "stop"
        }
        if (on) ctx.startForegroundService(i) else ctx.stopService(i)
        WidgetTransition.animateModeChange(ctx)
        if (on) WidgetUpdater.scheduleTick(ctx) else WidgetUpdater.cancelTick(ctx)
    }

    companion object {
        const val ACTION_TOGGLE_LISTEN = "com.echo.app.WIDGET_TOGGLE_LISTEN"
        const val ACTION_START_LIVE = "com.echo.app.WIDGET_START_LIVE"
        const val ACTION_STOP_LIVE = "com.echo.app.WIDGET_STOP_LIVE"
    }
}
